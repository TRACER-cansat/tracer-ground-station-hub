#!/usr/bin/env python3
"""PC-resident launcher and offline page for TRACER Ground Station.

This process deliberately runs on the operator PC.  It remains available when
the rover is powered down, starts the Pi program via SSH when requested, and
serves the operator screen locally while the Pi APIs are reached over Wi-Fi.
"""

import argparse
import importlib.util
import json
import re
import secrets
import shutil
import socket
import subprocess
import sys
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from urllib.parse import parse_qs, urlsplit

from browser_voice import WebSocketPcm, bridge_audio


ROOT = Path(__file__).resolve().parent
WEB = ROOT / "ground_station_hub_web"
STATION_WEB = ROOT / "ground_station_web"
REMOTE_DIR = "/home/razupai_zero2/for-TRACER-git"
REMOTE_SESSION = "tracer-ground-station"
DEFAULT_SSH_TARGETS = (
    "razupai_zero2@razupai2",
    "razupai_zero2@razupai2.local",
    "razupai_zero2@192.168.12.15",
)


def normalise_targets(targets):
    """Keep externally supplied SSH targets as plain user@host values."""
    if isinstance(targets, str):
        targets = (targets,)
    result = []
    for target in targets:
        target = str(target).strip()
        if (target and len(target) <= 255 and not target.startswith("-")
                and re.fullmatch(r"[A-Za-z0-9_.@:-]+", target)
                and target not in result):
            result.append(target)
    if not result:
        raise ValueError("SSH接続先を入力してください")
    return tuple(result)


class RoverSession:
    """Manage the Pi program over SSH and read its API over the LAN."""

    def __init__(self, target, station_port=8766, voice_port=50100, share_host=None,
                 remote_dir=REMOTE_DIR, session=REMOTE_SESSION,
                 popen=subprocess.Popen, run=subprocess.run):
        self.targets = normalise_targets(target)
        self.target = self.targets[0]
        self.station_port = station_port
        self.voice_port = voice_port
        self.manual_share_host = share_host
        self.remote_dir = remote_dir
        self.session = session
        self.popen = popen
        self.run = run
        self.remote_token = None
        self.last_instance = None
        self.restart_instance = None
        self.phase_started = time.monotonic()
        self.lock = threading.RLock()
        self.phase = "offline"
        self.detail = "ローバー未接続。接続を開始できます。"
        self.last_error = ""

    @property
    def station_url(self):
        host = self.target.rsplit("@", 1)[-1]
        return f"http://{host}:{self.station_port}"

    @property
    def station_share_url(self):
        return f"http://{self.share_host}:{self.station_port}"

    @property
    def share_host(self):
        # A tethered PC receives a new address at each Wi-Fi connection.
        return self.manual_share_host or self._detect_share_host()

    def set_target(self, target):
        with self.lock:
            if self.phase in ("starting", "connecting", "connected", "stopping"):
                return False
            self.targets = normalise_targets(target)
            self.target = self.targets[0]
            self.remote_token = None
            self.detail = f"接続先を {self.target} に設定しました。"
        return True

    @staticmethod
    def _detect_share_host():
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("192.0.2.1", 1))
            return probe.getsockname()[0]
        except OSError:
            return socket.gethostbyname(socket.gethostname())
        finally:
            probe.close()

    def _ssh(self, remote_command, timeout=15, target=None):
        return self.run(
            ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
             target or self.target, remote_command],
            capture_output=True, text=True, timeout=timeout, check=False,
        )

    def _remote_start_command(self):
        command = (
            f"cd {self.remote_dir} && "
            f"if tmux has-session -t {self.session} 2>/dev/null; then "
            f"tmux send-keys -t {self.session}:0 C-c; "
            "for attempt in 1 2 3 4 5 6 7 8 9 10; do "
            f"tmux has-session -t {self.session} 2>/dev/null || break; "
            "sleep 1; done; "
            f"tmux has-session -t {self.session} 2>/dev/null && "
            "{ echo '既存の地上局が終了していません' >&2; exit 1; }; "
            "fi; "
            f"tmux new-session -d -s {self.session} -c {self.remote_dir} "
            "'env PYTHONPATH=/home/razupai_zero2/DFRobot_GNSS/python/raspberrypi "
            f"python3 -u rover.py --port {self.station_port} --allow-network-clients'"
        )
        return command

    def start(self):
        with self.lock:
            if self.phase in ("starting", "connecting", "connected", "stopping"):
                return False
            self.phase, self.detail = "starting", "SSH接続とローバーコードを開始中です。"
            self.phase_started = time.monotonic()
        try:
            errors = []
            deploy = (
                (ROOT / "ground_station.py", f"{self.remote_dir}/ground_station.py"),
                (ROOT / "rover_system.py", f"{self.remote_dir}/rover_system.py"),
                (ROOT / "rover_drive_sensors.py",
                 f"{self.remote_dir}/rover_drive_sensors.py"),
                (STATION_WEB / "index.html", f"{self.remote_dir}/ground_station_web/index.html"),
                (STATION_WEB / "app.js", f"{self.remote_dir}/ground_station_web/app.js"),
                (STATION_WEB / "style.css", f"{self.remote_dir}/ground_station_web/style.css"),
                (STATION_WEB / "voice_browser.js", f"{self.remote_dir}/ground_station_web/voice_browser.js"),
                (STATION_WEB / "map.html", f"{self.remote_dir}/ground_station_web/map.html"),
                (STATION_WEB / "map.js", f"{self.remote_dir}/ground_station_web/map.js"),
                (STATION_WEB / "map_relative.js", f"{self.remote_dir}/ground_station_web/map_relative.js"),
                (ROOT / "rover.py", f"{self.remote_dir}/rover.py"),
                (ROOT / "drive.py", f"{self.remote_dir}/drive.py"),
                (ROOT / "tracer_runtime" / "system_supervisor.py",
                 f"{self.remote_dir}/tracer_runtime/system_supervisor.py"),
                (ROOT / "tracer_runtime" / "voice_link.py",
                 f"{self.remote_dir}/tracer_runtime/voice_link.py"),
            )
            for candidate in self.targets:
                for source, destination in deploy:
                    copy = self.run(
                        ["scp", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
                         str(source), f"{candidate}:{destination}"],
                        capture_output=True, text=True, timeout=20, check=False,
                    )
                    if copy.returncode:
                        errors.append((copy.stderr or copy.stdout or str(source)).strip())
                        break
                else:
                    result = self._ssh(self._remote_start_command(), timeout=25,
                                       target=candidate)
                    if not result.returncode:
                        self.target = candidate
                        break
                    errors.append((result.stderr or result.stdout or candidate).strip())
                    continue
            else:
                raise RuntimeError(" / ".join(errors) or "SSH接続に失敗しました")
            with self.lock:
                self.remote_token = None
                self.phase = "connecting"
                self.phase_started = time.monotonic()
                self.detail = "ローバーを起動しました。カメラ初期化を待っています。"
            return True
        except Exception as error:
            with self.lock:
                self.phase, self.last_error = "offline", str(error)
                self.detail = f"接続できません: {error}"
            return False

    def refresh(self):
        with self.lock:
            phase = self.phase
        # An offline rover name can take several seconds to resolve. Keep the
        # public page responsive until an operator explicitly starts the Pi.
        if phase in ("starting", "stopping", "offline"):
            return self.status()

        try:
            with urlopen(self.station_url + "/api/state", timeout=.6) as response:
                state = json.load(response)
            if "error" in state:
                raise ValueError(state["error"])
            with self.lock:
                if (self.phase == "restarting" and self.restart_instance
                        and state.get("instance_id") == self.restart_instance):
                    return self.status(state)
                if (self.last_instance and state.get("instance_id") != self.last_instance):
                    self.remote_token = None
                self.phase = "connected"
                self.detail = "接続中。地上局を開いて操作できます。"
                self.last_instance = state.get("instance_id")
                self.restart_instance = None
            return self.status(state)
        except (OSError, ValueError):
            with self.lock:
                if self.phase == "connected":
                    self.phase = "reconnecting"
                    self.detail = "ローバーへ再接続中です。操作画面は表示されたままです。"
                elif self.phase == "connecting" and time.monotonic() - self.phase_started > 30:
                    self.phase = "reconnecting"
                    self.detail = "ローバーの起動応答がありません。接続と実機ログを確認してください。"
                elif self.phase == "restarting" and time.monotonic() - self.phase_started > 30:
                    self.phase = "reconnecting"
                    self.detail = "コード再起動の応答がありません。実機ログを確認してください。"
                elif self.phase == "offline":
                    self.detail = "ローバー未接続。操作画面は表示できます。"
            return self.status()

    def probe_existing(self):
        """Detect a Pi program left running when the PC Hub restarts."""
        try:
            with urlopen(self.station_url + "/api/state", timeout=1) as response:
                state = json.load(response)
            if "error" not in state:
                with self.lock:
                    if self.phase == "offline":
                        self.phase = "connecting"
                self.refresh()
        except (OSError, ValueError):
            pass

    def mark_restart(self):
        with self.lock:
            self.restart_instance = self.last_instance
            self.phase = "restarting"
            self.phase_started = time.monotonic()
            self.detail = "ローバーのコードを再起動中です。画面は表示されたままです。"

    def token_for_rover(self, refresh=False):
        with self.lock:
            if self.remote_token and not refresh:
                return self.remote_token
        with urlopen(self.station_url + "/api/session", timeout=2) as response:
            token = json.load(response)["token"]
        with self.lock:
            self.remote_token = token
        return token

    def status(self, station=None):
        with self.lock:
            return {
                "phase": self.phase,
                "detail": self.detail,
                "station_url": self.station_url,
                "station_share_url": self.station_share_url,
                "voice_port": self.voice_port,
                "target": self.target,
                "targets": self.targets,
                "station": station,
            }

    def stop(self):
        with self.lock:
            self.phase, self.detail = "stopping", "ローバーのコードを終了中です。"
        try:
            result = self._ssh(
                f"tmux has-session -t {self.session} 2>/dev/null || exit 0; "
                f"tmux send-keys -t {self.session}:0 C-c; "
                "for attempt in 1 2 3 4 5 6 7 8 9 10; do "
                f"tmux has-session -t {self.session} 2>/dev/null || exit 0; "
                "sleep 1; done; "
                "echo '既存の地上局が終了していません' >&2; exit 1",
                timeout=25)
            if result.returncode:
                raise RuntimeError((result.stderr or result.stdout or "停止失敗").strip())
        except Exception as error:
            with self.lock:
                self.phase = "reconnecting"
                self.detail = f"終了を確認できません: {error}"
            return False
        finally:
            with self.lock:
                self.remote_token = None
                self.last_instance = None
        with self.lock:
            self.phase = "offline"
            self.detail = "ローバーコードを終了しました。Raspberry Pi本体は動作したままです。"
        return True

    def close(self):
        pass


class VoiceManager:
    """Run the PC audio endpoint only while the operator requests a call."""

    def __init__(self, session, popen=subprocess.Popen):
        self.session = session
        self.popen = popen
        self.process = None
        self.browser_socket = None
        self.lock = threading.RLock()
        self.lines = deque(maxlen=12)
        self.detail = "通話停止中"

    def _set_rover_mode(self, enabled):
        body = json.dumps({"client": "hub-voice", "key": "voice_start" if enabled else "voice_stop",
                           "sequence": time.time_ns()}).encode()
        for attempt in range(2):
            try:
                token = self.session.token_for_rover(refresh=bool(attempt))
                request = Request(self.session.station_url + "/api/command", body,
                                  {"X-Station-Token": token, "Content-Type": "application/json"},
                                  method="POST")
                with urlopen(request, timeout=2) as response:
                    return bool(json.load(response).get("accepted"))
            except (OSError, ValueError, KeyError):
                continue
        return False

    def _read_output(self, process):
        try:
            for line in process.stdout:
                line = line.strip()
                if line:
                    with self.lock:
                        self.lines.append(line)
                        if self.process is process:
                            self.detail = line
        except (OSError, ValueError):
            pass

    def status(self):
        with self.lock:
            process = self.process
            if process is not None and process.poll() is not None:
                self.process = None
                self._set_rover_mode(False)
                if process.returncode:
                    self.detail = self.lines[-1] if self.lines else f"音声クライアント終了 ({process.returncode})"
                else:
                    self.detail = self.lines[-1] if self.lines else "通話が終了しました"
            return {"running": self.process is not None or self.browser_socket is not None,
                    "browser": self.browser_socket is not None, "detail": self.detail}

    def start(self):
        with self.lock:
            if self.status()["running"]:
                return False
            if self.session.refresh()["phase"] != "connected":
                self.detail = "ローバーに接続してから通話を開始してください"
                return False
            if importlib.util.find_spec("sounddevice") is None:
                self.detail = "PCに sounddevice がありません。requirements-pc.txt をインストールしてください"
                return False
            if not self._set_rover_mode(True):
                self.detail = "ローバーを停止できないため通話を開始しません"
                return False
            host = self.session.station_url.split("://", 1)[1].rsplit(":", 1)[0]
            self.lines.clear()
            try:
                self.process = self.popen(
                    [sys.executable, "-u", str(ROOT / "ground_station_voice_client.py"),
                     "--host", host, "--port", str(self.session.voice_port)],
                    cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
            except OSError as error:
                self._set_rover_mode(False)
                self.detail = f"音声クライアントを起動できません: {error}"
                return False
            self.detail = "通話を接続中"
            threading.Thread(target=self._read_output, args=(self.process,), daemon=True,
                             name="voice-client-output").start()
            return True

    def start_browser(self):
        with self.lock:
            if self.status()["running"]:
                self.detail = "別の通話が使用中です"
                return None
            if self.session.refresh()["phase"] != "connected":
                self.detail = "ローバーに接続してから通話を開始してください"
                return None
            if not self._set_rover_mode(True):
                self.detail = "ローバーを停止できないため通話を開始しません"
                return None
            host = self.session.station_url.split("://", 1)[1].rsplit(":", 1)[0]
            try:
                rover = socket.create_connection((host, self.session.voice_port), timeout=5)
                rover.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError as error:
                self._set_rover_mode(False)
                self.detail = f"ローバーの通話に接続できません: {error}"
                return None
            self.browser_socket = rover
            self.detail = "ブラウザで双方向通話中"
            return rover

    def finish_browser(self, rover):
        with self.lock:
            if self.browser_socket is rover:
                self.browser_socket = None
                self.detail = "通話停止中"
                self._set_rover_mode(False)

    def stop(self):
        with self.lock:
            process = self.process
            browser = self.browser_socket
            self.process = None
            self.browser_socket = None
            self.detail = "通話停止中"
        if browser is not None:
            try:
                browser.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            browser.close()
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1)
        self._set_rover_mode(False)
        return True


class Hub:
    def __init__(self, session, port=8770):
        self.session = session
        self.port = port
        self.token = secrets.token_urlsafe(32)
        self.voice = VoiceManager(session)

    @property
    def share_url(self):
        return f"http://{self.session.share_host}:{self.port}"

    @property
    def public_station_url(self):
        path = ROOT / "public_runtime" / "current_url.txt"
        try:
            value = path.read_text(encoding="utf-8").strip()
        except OSError:
            return ""
        return value if re.fullmatch(r"https://[a-z0-9-]+\.trycloudflare\.com", value) else ""

    def setup_zip(self):
        from build_public_package import build
        return build()


class SingleInstanceHTTPServer(ThreadingHTTPServer):
    # Windows permits multiple listeners on one port with SO_REUSEADDR.
    # Keep Hub and Station on the same process after a second launch attempt.
    allow_reuse_address = False


def make_handler(hub):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def send(self, code, body, content_type="application/json"):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path == "/api/status":
                status = hub.session.refresh()
                status["hub_share_url"] = hub.share_url
                status["public_station_url"] = hub.public_station_url
                return self.send(200, json.dumps(status).encode())
            if path == "/api/session":
                return self.send(200, json.dumps({"token": hub.token}).encode())
            if path == "/downloads/setup.zip":
                path = hub.setup_zip()
                return self.send(200, path.read_bytes(), "application/zip")
            files = {"/": (WEB / "index.html", "text/html; charset=utf-8"),
                     "/app.js": (WEB / "app.js", "text/javascript; charset=utf-8"),
                     "/style.css": (WEB / "style.css", "text/css; charset=utf-8")}
            if path in files:
                source, content_type = files[path]
                return self.send(200, source.read_bytes(), content_type)
            return self.send(404, b"{}")

        def do_POST(self):
            if self.path != "/api/action" or self.headers.get("X-Hub-Token") != hub.token:
                return self.send(403, b"{}")
            try:
                size = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(size))
                action = body.get("action")
                if action == "start":
                    accepted = hub.session.start()
                elif action == "stop":
                    hub.voice.stop()
                    accepted = hub.session.stop()
                elif action == "configure":
                    accepted = hub.session.set_target(body.get("target", ""))
                else:
                    return self.send(400, b"{}")
                return self.send(202 if accepted else 409,
                                 json.dumps({"accepted": accepted}).encode())
            except (ValueError, OSError, json.JSONDecodeError):
                return self.send(400, b"{}")
    return Handler


def make_station_handler(hub):
    """Always available PC screen; relay only the known rover API routes."""
    hub_handler = make_handler(hub)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def send(self, code, body, content_type="application/json"):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def local_operator(self):
            peer = self.client_address[0]
            return peer in ("127.0.0.1", "::1") or peer == self.connection.getsockname()[0]

        def relay_get(self, path, timeout=2):
            try:
                with urlopen(hub.session.station_url + path, timeout=timeout) as response:
                    if path == "/api/state" and hub.session.remote_token is None:
                        try:
                            hub.session.token_for_rover()
                        except (OSError, KeyError, ValueError):
                            pass
                    return self.send(response.status, response.read(),
                                     response.headers.get("Content-Type", "application/json"))
            except HTTPError as error:
                return self.send(error.code, error.read())
            except (OSError, TimeoutError):
                if path == "/api/source":
                    return self.send(200, b"[]")
                if path == "/api/log":
                    return self.send(200, json.dumps({"log": "ローバー未接続"}).encode())
                return self.send(503, json.dumps({"error": "ローバー未接続"}).encode())

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path == "/hub":
                self.send_response(308)
                self.send_header("Location", "/hub/")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            if path.startswith("/hub/"):
                self.path = self.path[4:]
                return hub_handler.do_GET(self)
            if path == "/api/voice-stream":
                query = parse_qs(urlsplit(self.path).query)
                origin = self.headers.get("Origin", "")
                if (query.get("token", [None])[0] != hub.token or
                    urlsplit(origin).netloc != self.headers.get("Host")):
                    return self.send(403, b"{}")
                websocket = WebSocketPcm(self)
                rover = hub.voice.start_browser()
                if rover is None:
                    return self.send(409, json.dumps(hub.voice.status()).encode())
                try:
                    if not websocket.upgrade():
                        return self.send(400, b"{}")
                    self.close_connection = True
                    bridge_audio(websocket, rover, threading.Event())
                finally:
                    hub.voice.finish_browser(rover)
                return
            if path == "/api/hub-status":
                status = hub.session.refresh()
                status["hub_share_url"] = hub.share_url
                status["public_station_url"] = hub.public_station_url
                return self.send(200, json.dumps(status).encode())
            if path == "/api/session":
                return self.send(200, json.dumps({"token": hub.token}).encode())
            if path == "/api/voice":
                return self.send(200, json.dumps({**hub.voice.status(),
                                                  "available": self.local_operator()}).encode())
            if path in ("/api/state", "/api/source", "/api/log"):
                return self.relay_get(path, timeout=.8 if path == "/api/state" else 2)
            if path == "/video_feed":
                try:
                    with urlopen(hub.session.station_url + "/video_feed", timeout=3) as upstream:
                        self.send_response(200)
                        self.send_header("Content-Type", upstream.headers.get("Content-Type", "multipart/x-mixed-replace"))
                        self.send_header("Cache-Control", "no-store")
                        self.end_headers()
                        while True:
                            chunk = upstream.read1(8192)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            self.wfile.flush()
                except (OSError, TimeoutError):
                    pass
                return
            files = {"/": "index.html", "/app.js": "app.js", "/style.css": "style.css",
                     "/map": "map.html", "/map.js": "map.js", "/map_relative.js": "map_relative.js",
                     "/voice_browser.js": "voice_browser.js"}
            if path in files:
                source = STATION_WEB / files[path]
                content_type = {".html": "text/html; charset=utf-8",
                                ".js": "text/javascript; charset=utf-8",
                                ".css": "text/css; charset=utf-8"}[source.suffix]
                return self.send(200, source.read_bytes(), content_type)
            return self.send(404, b"{}")

        def do_POST(self):
            if self.path.startswith("/hub/"):
                self.path = self.path[4:]
                return hub_handler.do_POST(self)
            if self.path not in ("/api/command", "/api/hub-action", "/api/voice") or self.headers.get("X-Station-Token") != hub.token:
                return self.send(403, b"{}")
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size < 1024:
                    raise ValueError("size")
                body = self.rfile.read(size)
                if self.path == "/api/voice":
                    if not self.local_operator():
                        return self.send(403, json.dumps({"error": "PC上の画面から操作してください"}).encode())
                    action = json.loads(body).get("action")
                    if action == "start":
                        accepted = hub.voice.start()
                    elif action == "stop":
                        accepted = hub.voice.stop()
                    else:
                        raise ValueError("action")
                    return self.send(202 if accepted else 409,
                                     json.dumps({"accepted": accepted, **hub.voice.status()}).encode())
                if self.path == "/api/hub-action":
                    action = json.loads(body).get("action")
                    if action == "start":
                        accepted = hub.session.start()
                    elif action == "stop":
                        hub.voice.stop()
                        accepted = hub.session.stop()
                    else:
                        raise ValueError("action")
                    return self.send(202 if accepted else 409,
                                     json.dumps({"accepted": accepted}).encode())
                key = json.loads(body).get("key")
                if not isinstance(key, str):
                    raise ValueError("key")
                for attempt in range(2):
                    token = hub.session.token_for_rover(refresh=bool(attempt))
                    request = Request(hub.session.station_url + "/api/command", body,
                                      {"X-Station-Token": token,
                                       "Content-Type": "application/json"}, method="POST")
                    try:
                        with urlopen(request, timeout=2) as response:
                            result = response.read()
                            if key == "restart" and response.status == 200:
                                hub.session.mark_restart()
                            return self.send(response.status, result)
                    except HTTPError as error:
                        if error.code == 403 and not attempt:
                            continue
                        return self.send(error.code, error.read())
            except (OSError, TimeoutError):
                return self.send(503, json.dumps({"error": "ローバー未接続"}).encode())
            except (ValueError, TypeError, json.JSONDecodeError):
                return self.send(400, b"{}")
    return Handler


def main():
    parser = argparse.ArgumentParser(description="TRACER PC Ground Station Hub")
    parser.add_argument("--host", default="0.0.0.0", help="PC側の公開アドレス")
    parser.add_argument("--port", type=int, default=8770)
    parser.add_argument("--ssh-target", action="append",
                        help="SSH接続先。複数指定時は順に試行します")
    parser.add_argument("--station-port", type=int, default=8766)
    parser.add_argument("--voice-port", type=int, default=50100)
    parser.add_argument("--share-host", help="共有リンクに表示するPCのIPアドレスまたはホスト名")
    args = parser.parse_args()
    session = RoverSession(args.ssh_target or DEFAULT_SSH_TARGETS,
                           args.station_port, args.voice_port, args.share_host)
    hub = Hub(session, args.port)
    server = SingleInstanceHTTPServer((args.host, args.port), make_handler(hub))
    server.daemon_threads = True
    station_server = SingleInstanceHTTPServer(
        (args.host, args.station_port), make_station_handler(hub))
    station_server.daemon_threads = True
    threading.Thread(target=station_server.serve_forever, daemon=True,
                     name="pc-ground-station").start()
    threading.Thread(target=session.probe_existing, daemon=True,
                     name="rover-existing-session-probe").start()
    print(f"TRACER Hub: http://127.0.0.1:{args.port}", flush=True)
    print(f"TRACER Station: http://127.0.0.1:{args.station_port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        hub.voice.stop()
        server.server_close()
        station_server.shutdown()
        station_server.server_close()
        session.close()


if __name__ == "__main__":
    main()
