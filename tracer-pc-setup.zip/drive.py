#!/usr/bin/env python3
"""Drive and sensor worker launched by rover.py."""

from rover_drive_sensors import main


if __name__ == "__main__":
    main()
