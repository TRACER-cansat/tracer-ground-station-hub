"""Dependency-free WebSocket bridge between a browser and the rover PCM link."""

import base64
import binascii
import hashlib
import socket
import struct
import threading


GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
HEADER = struct.Struct("!4sIHH")
MAGIC = b"Z2W1"
RATE = 8000
PCM_BYTES = 320  # 20 ms, signed 16-bit mono


def read_exact(stream, size):
    data = bytearray()
    while len(data) < size:
        chunk = stream.read(size - len(data))
        if not chunk:
            raise EOFError("voice connection closed")
        data.extend(chunk)
    return bytes(data)


class WebSocketPcm:
    def __init__(self, handler):
        self.handler = handler
        self.send_lock = threading.Lock()

    def upgrade(self):
        key = self.handler.headers.get("Sec-WebSocket-Key", "")
        if (self.handler.headers.get("Upgrade", "").lower() != "websocket"
                or self.handler.headers.get("Sec-WebSocket-Version") != "13"
                or len(key) > 128):
            return False
        try:
            if len(base64.b64decode(key, validate=True)) != 16:
                return False
        except (ValueError, binascii.Error, UnicodeEncodeError):
            return False
        accept = base64.b64encode(hashlib.sha1((key + GUID).encode("ascii")).digest()).decode("ascii")
        self.handler.send_response(101)
        self.handler.send_header("Upgrade", "websocket")
        self.handler.send_header("Connection", "Upgrade")
        self.handler.send_header("Sec-WebSocket-Accept", accept)
        self.handler.end_headers()
        return True

    def receive(self):
        first, second = read_exact(self.handler.rfile, 2)
        if first & 0x70 or not first & 0x80 or not second & 0x80:
            raise ValueError("invalid browser WebSocket frame")
        opcode, size = first & 15, second & 127
        if size == 126:
            size = struct.unpack("!H", read_exact(self.handler.rfile, 2))[0]
        elif size == 127:
            size = struct.unpack("!Q", read_exact(self.handler.rfile, 8))[0]
        if size > 4096:
            raise ValueError("voice frame too large")
        mask = read_exact(self.handler.rfile, 4)
        payload = read_exact(self.handler.rfile, size)
        payload = bytes(value ^ mask[index % 4] for index, value in enumerate(payload))
        if opcode == 8:
            raise EOFError("browser ended voice session")
        if opcode == 9:
            self.send(payload, opcode=10)
            return None
        if opcode != 2 or len(payload) != PCM_BYTES:
            raise ValueError("invalid browser PCM frame")
        return payload

    def send(self, pcm, opcode=2):
        size = len(pcm)
        frame = bytes([0x80 | opcode, size if size < 126 else 126])
        if size >= 126:
            frame += struct.pack("!H", size)
        with self.send_lock:
            self.handler.wfile.write(frame + pcm)
            self.handler.wfile.flush()


def bridge_audio(websocket, rover, stop):
    """Relay 20 ms PCM frames, keeping no unbounded audio queue."""
    rover.settimeout(.4)

    def browser_to_rover():
        sequence = 0
        try:
            while not stop.is_set():
                pcm = websocket.receive()
                if pcm is not None:
                    rover.sendall(HEADER.pack(MAGIC, sequence, RATE, PCM_BYTES // 2) + pcm)
                    sequence = (sequence + 1) & 0xffffffff
        except (EOFError, OSError, ValueError):
            stop.set()

    worker = threading.Thread(target=browser_to_rover, daemon=True, name="browser-voice-send")
    worker.start()
    try:
        while not stop.is_set():
            header = recv_exact(rover, HEADER.size, stop)
            magic, _sequence, rate, samples = HEADER.unpack(header)
            if magic != MAGIC or rate != RATE or samples != PCM_BYTES // 2:
                raise ValueError("invalid rover PCM frame")
            websocket.send(recv_exact(rover, PCM_BYTES, stop))
    except (EOFError, OSError, ValueError):
        pass
    finally:
        stop.set()
        try:
            rover.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        rover.close()
        worker.join(timeout=1)


def recv_exact(sock, size, stop):
    data = bytearray()
    while len(data) < size and not stop.is_set():
        try:
            chunk = sock.recv(size - len(data))
        except socket.timeout:
            continue
        if not chunk:
            raise EOFError("rover voice link closed")
        data.extend(chunk)
    if len(data) != size:
        raise EOFError("voice session stopped")
    return bytes(data)
