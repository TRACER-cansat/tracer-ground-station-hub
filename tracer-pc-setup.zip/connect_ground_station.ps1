﻿param(
    [string]$Rover = "",
    [int]$HubPort = 8770
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$publicScript = Join-Path $here 'start_public_ground_station.ps1'
if (Test-Path -LiteralPath $publicScript) {
    & $publicScript -HubPort $HubPort -StationPort 8766 -Rover $Rover
    return
}
$arguments = @("$here\hub.py", "--port", $HubPort)
if ($Rover) { $arguments += @("--ssh-target", $Rover) }
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (Test-Path -LiteralPath $bundledPython) {
    & $bundledPython @arguments
} else {
    py -3 @arguments
}
