param(
    [string]$Rover = "",
    [int]$HubPort = 8770
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$publicScript = Join-Path $here 'start_public_ground_station.ps1'
if (Test-Path -LiteralPath $publicScript) {
    $runtime = Join-Path $here 'public_runtime'
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    Start-Process -FilePath 'powershell.exe' -ArgumentList @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$publicScript`"") `
        -WorkingDirectory $here -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $runtime 'startup.out.log') `
        -RedirectStandardError (Join-Path $runtime 'startup.err.log') | Out-Null
}
$arguments = @("$here\hub.py", "--port", $HubPort)
if ($Rover) { $arguments += @("--ssh-target", $Rover) }
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (Test-Path -LiteralPath $bundledPython) {
    & $bundledPython @arguments
} else {
    py -3 @arguments
}
