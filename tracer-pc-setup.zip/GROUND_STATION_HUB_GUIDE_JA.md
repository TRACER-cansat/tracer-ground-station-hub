# TRACER PC Ground Station Hub

## 別Wi-Fiからの公開操作画面

地上局PCとローバーを同じWi-Fiへ接続し、PCで `start_public_ground_station.ps1` を実行する。PC内の公開用Hub（8870）と操作画面（8866）を起動し、Cloudflareの一時HTTPS URLを表示する。別Wi-Fiの端末ではそのURLを開く。映像・計測・操作・マップはPC経由でPiへ中継し、HTTPS画面の通話ボタンは開いた端末のマイクとスピーカーを使用する。PC側からPiへのファイル転送と起動は従来どおりSSHを使う。

Cloudflare Quick Tunnelは独自ドメインやアカウントなしで使えるが、URLはトンネルを起動し直すと変わり、稼働率の保証がない。現在のURLは `public_runtime/current_url.txt` と公開用Hubの「別Wi-Fi用のHTTPSリンク」に表示する。URLを知る人には操作権限が渡るため、共有先を確認すること。地上局PCまたはローバーが停止中は、操作画面は開けても実機の映像・制御は使えない。

GitHub Pages用の静的な案内画面は `docs/index.html`、PC一式の配布ZIPは `docs/tracer-pc-setup.zip`。`build_public_package.py` で再生成できる。Pages上の案内画面は公開URLを入力して操作画面を開く方式で、PiやPCのPython処理をGitHub Pages上で実行しない。

`hub.py`はPCで動く常駐入口です。ローバーが未接続でも画面とPCセットアップ配布を表示します。

```powershell
cd for-TRACER-github
py -3 hub.py
```

ブラウザで`http://localhost:8770`（入口）または`http://localhost:8766`（操作画面）を開きます。どちらもPC上で常時表示され、ローバーの電源が切れていてもページを開けます。同じWi-Fiの端末には、Hubに表示されるPCの共有リンクを渡します。PCが稼働している間はリンクを開けます。

発表時の起動ファイル名は、PC側が`hub.py`、Raspberry Pi側が`rover.py`、駆動・センサーの子処理が`drive.py`です。内部実装は`rover_system.py`と`rover_drive_sensors.py`です。

## 初回のSSH準備

Web画面からパスワードを扱わないため、PCで鍵認証を一度設定します。以後はローバーの電源投入後にHubまたは操作画面の「接続して開始」だけで、SSHを使って実機側の`rover.py`を開始できます。

```powershell
ssh-keygen -t ed25519
type $env:USERPROFILE\.ssh\id_ed25519.pub | ssh razupai_zero2@razupai2 "mkdir -p ~/.ssh; cat >> ~/.ssh/authorized_keys"
```

## 操作

- **接続して開始**: 最新の`rover.py`と`drive.py`、操作画面をPiへ配備し、Pi側のtmuxセッションを起動する。
- **操作画面を開く**: ローバー未接続時も開く。画面の「接続・起動」「コード終了」から一連の操作を行える。
- **ローバーコードを終了**: Step 7を含むPi上の地上局コードを終了する。Raspberry Pi本体は動作を続ける。
- **PCセットアップをダウンロード**: 音声通話クライアントとPC設定ファイルを取得する。
- **通話開始 / 通話停止**: Hubを動かしているPCの操作画面でボタンを押すか、`V`キーで切り替える。PCの既定マイクとスピーカーを使用する。Pi接続中のみ開始でき、操作はHub PC自身からに限る。通話中はローバーの走行を停止して指令を拒否する。PC音声はPiのGPIO12にpigpio PWMで出力するため、Piでpigpiodが必要（未起動時は自動起動を試行）。

このPCではWindowsのスタートアップに`connect_ground_station.ps1`のショートカットを登録済みです。再ログイン後にHubと操作画面が起動します。PCの電源が切れている間はリンクを開けません。別のPCでセットアップする場合も、そのPCのスタートアップに同じスクリプトのショートカットを登録してください。

操作画面と映像・センサーデータはPCの8766番を入口とし、PCからPiの8766番へ同じWi-Fi内で直接HTTP接続します。SSHのポート転送は使用しません。音声クライアントはPiの50100番へ直接接続します（`python ground_station_voice_client.py --host razupai2`）。各ブラウザの表示は未接続、起動中、再接続中、コード再起動中、カメラ再接続中を更新します。HTTPのため、操作は同じ信頼できるWi-Fi内で行ってください。

## スマホのテザリング / Wi-Fi変更

PCとローバーを**同じテザリングまたは同じWi-Fi**へ接続すれば使用できます。HubはPCの共有IPを都度検出するため、Wi-Fiを切り替えた後はHub画面に表示された新しいリンクを使用してください。ローバー側は`razupai2`、`razupai2.local`、以前の固定IPの順で自動接続を試みます。

名前で見つからないネットワークでは、Hub上の「SSH接続先」に`razupai_zero2@新しいIPアドレス`を入力して「接続先を設定」を押します。テザリングで初めて接続するときだけIPの確認が必要になる場合があります。スマホ回線越しにインターネット全体へ公開する構成ではなく、同じローカルネットワーク内でのみ操作できます。
