#!/usr/bin/env python3
"""
PC voice endpoint.

Run this on the operator PC. It connects to the Raspberry Pi script, sends the
PC microphone, and plays the Raspberry Pi microphone through the PC speaker.
"""

from __future__ import annotations

import argparse
import queue
import socket
import struct
import sys
import threading
import time
from typing import Optional


try:
    import sounddevice as sd  # type: ignore
except ImportError as exc:
    raise SystemExit(
        "sounddevice is not installed. Run: python -m pip install sounddevice"
    ) from exc


MAGIC = b"Z2W1"
HEADER = struct.Struct("!4sIHH")  # magic, sequence, sample_rate, samples
SAMPLE_BYTES = 2


def put_live(q: queue.Queue[bytes], item: bytes) -> None:
    try:
        q.put_nowait(item)
        return
    except queue.Full:
        pass

    try:
        q.get_nowait()
    except queue.Empty:
        pass

    try:
        q.put_nowait(item)
    except queue.Full:
        pass


def make_frame(seq: int, rate: int, payload: bytes) -> bytes:
    samples = len(payload) // SAMPLE_BYTES
    return HEADER.pack(MAGIC, seq & 0xFFFFFFFF, rate, samples) + payload


def read_exact(sock: socket.socket, size: int, stop: threading.Event) -> bytes:
    data = bytearray()
    while len(data) < size and not stop.is_set():
        try:
            chunk = sock.recv(size - len(data))
        except socket.timeout:
            continue
        if not chunk:
            raise EOFError("connection closed")
        data.extend(chunk)
    return bytes(data)


def read_frame(sock: socket.socket, stop: threading.Event) -> tuple[int, int, bytes]:
    header = read_exact(sock, HEADER.size, stop)
    if len(header) != HEADER.size:
        raise EOFError("connection closed")

    magic, seq, rate, samples = HEADER.unpack(header)
    if magic != MAGIC:
        raise ValueError("bad audio frame magic")

    payload_size = samples * SAMPLE_BYTES
    payload = read_exact(sock, payload_size, stop)
    if len(payload) != payload_size:
        raise EOFError("connection closed")
    return seq, rate, payload


def sender_loop(
    sock: socket.socket,
    send_q: queue.Queue[bytes],
    rate: int,
    stop: threading.Event,
) -> None:
    seq = 0
    while not stop.is_set():
        try:
            payload = send_q.get(timeout=0.2)
        except queue.Empty:
            continue

        try:
            sock.sendall(make_frame(seq, rate, payload))
        except OSError as exc:
            print(f"send failed: {exc}", file=sys.stderr)
            stop.set()
            break
        seq += 1


def receiver_loop(
    sock: socket.socket,
    play_q: queue.Queue[bytes],
    expected_rate: int,
    stop: threading.Event,
) -> None:
    while not stop.is_set():
        try:
            _seq, rate, payload = read_frame(sock, stop)
        except (EOFError, OSError, ValueError) as exc:
            if not stop.is_set():
                print(f"receive stopped: {exc}", file=sys.stderr)
            stop.set()
            break

        if rate != expected_rate:
            continue
        put_live(play_q, payload)


def connect(host: str, port: int) -> socket.socket:
    sock = socket.create_connection((host, port), timeout=10.0)
    sock.settimeout(0.2)
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sock


def parse_device(value: Optional[str]) -> Optional[int | str]:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except ValueError:
        return value


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="PC endpoint for Raspberry Pi voice link.")
    parser.add_argument("--host", default="razupai2", help="Raspberry Pi host/IP")
    parser.add_argument("--port", type=int, default=50100, help="TCP port")
    parser.add_argument("--rate", type=int, default=8000, help="sample rate, must match Pi")
    parser.add_argument("--chunk-ms", type=int, default=20, help="audio frame size in ms")
    parser.add_argument("--input-device", help="sounddevice input device index/name")
    parser.add_argument("--output-device", help="sounddevice output device index/name")
    parser.add_argument("--list-devices", action="store_true", help="print audio devices and exit")
    parser.add_argument("--mute-mic", action="store_true")
    parser.add_argument("--mute-speaker", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.list_devices:
        print(sd.query_devices())
        return 0

    samples_per_chunk = int(args.rate * args.chunk_ms / 1000)
    chunk_bytes = samples_per_chunk * SAMPLE_BYTES
    silence = b"\x00" * chunk_bytes

    stop = threading.Event()
    send_q: queue.Queue[bytes] = queue.Queue(maxsize=8)
    play_q: queue.Queue[bytes] = queue.Queue(maxsize=8)

    def input_callback(indata, frames, _time_info, status) -> None:
        if status:
            pass
        if args.mute_mic:
            return
        data = bytes(indata)
        if len(data) != chunk_bytes:
            data = data[:chunk_bytes].ljust(chunk_bytes, b"\x00")
        put_live(send_q, data)

    def output_callback(outdata, frames, _time_info, status) -> None:
        if status:
            pass
        if args.mute_speaker:
            outdata[:] = silence
            return
        try:
            data = play_q.get_nowait()
        except queue.Empty:
            data = silence
        if len(data) != chunk_bytes:
            data = data[:chunk_bytes].ljust(chunk_bytes, b"\x00")
        outdata[:] = data

    sock: Optional[socket.socket] = None
    threads: list[threading.Thread] = []

    try:
        print(f"connecting to {args.host}:{args.port} ...")
        sock = connect(args.host, args.port)
        print("connected. Press Ctrl+C to stop.")

        threads.append(threading.Thread(target=sender_loop, args=(sock, send_q, args.rate, stop)))
        threads.append(threading.Thread(target=receiver_loop, args=(sock, play_q, args.rate, stop)))
        for t in threads:
            t.daemon = True
            t.start()

        streams = []
        if not args.mute_mic:
            streams.append(
                sd.RawInputStream(
                    samplerate=args.rate,
                    blocksize=samples_per_chunk,
                    channels=1,
                    dtype="int16",
                    device=parse_device(args.input_device),
                    callback=input_callback,
                )
            )
        if not args.mute_speaker:
            streams.append(
                sd.RawOutputStream(
                    samplerate=args.rate,
                    blocksize=samples_per_chunk,
                    channels=1,
                    dtype="int16",
                    device=parse_device(args.output_device),
                    callback=output_callback,
                )
            )

        for stream in streams:
            stream.start()

        try:
            while not stop.is_set():
                time.sleep(0.5)
        finally:
            for stream in streams:
                stream.stop()
                stream.close()

    except KeyboardInterrupt:
        print("\nstopping ...")
    finally:
        stop.set()
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        for t in threads:
            t.join(timeout=1.0)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
