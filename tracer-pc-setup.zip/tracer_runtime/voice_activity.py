import math
from array import array
from dataclasses import dataclass

from tracer_runtime.audio_capture import AudioFrame, FRAME_BYTES


@dataclass(frozen=True)
class VoiceEvent:
    kind: str
    sequence: int
    monotonic_ns: int
    level_dbfs: float
    threshold_dbfs: float


def pcm_rms_dbfs(pcm: bytes) -> float:
    if len(pcm) != FRAME_BYTES or len(pcm) % 2:
        raise ValueError(f"invalid PCM frame size: {len(pcm)}")
    samples = array("h")
    samples.frombytes(pcm)
    if not samples:
        return -96.0
    mean_square = sum(sample * sample for sample in samples) / len(samples)
    if mean_square <= 0:
        return -96.0
    return max(-96.0, 20.0 * math.log10(math.sqrt(mean_square) / 32768.0))


class VoiceActivityDetector:
    def __init__(
        self,
        minimum_threshold_dbfs=-42.0,
        noise_margin_db=10.0,
        activation_frames=3,
        release_frames=12,
        initial_noise_floor_dbfs=-60.0,
        noise_alpha=0.05,
    ):
        self.minimum_threshold_dbfs = minimum_threshold_dbfs
        self.noise_margin_db = noise_margin_db
        self.activation_frames = activation_frames
        self.release_frames = release_frames
        self.noise_floor_dbfs = initial_noise_floor_dbfs
        self.noise_alpha = noise_alpha
        self.active = False
        self.above_count = 0
        self.below_count = 0

    @property
    def threshold_dbfs(self):
        return max(self.minimum_threshold_dbfs, self.noise_floor_dbfs + self.noise_margin_db)

    def process(self, frame: AudioFrame, suppressed=False):
        level = pcm_rms_dbfs(frame.pcm)
        threshold = self.threshold_dbfs
        events = []
        if suppressed:
            self.above_count = 0
            if self.active:
                self.active = False
                self.below_count = 0
                events.append(VoiceEvent("voice_stop", frame.sequence, frame.monotonic_ns, level, threshold))
            return events

        above = level >= threshold
        if not self.active:
            if above:
                self.above_count += 1
            else:
                self.above_count = 0
                self.noise_floor_dbfs += self.noise_alpha * (level - self.noise_floor_dbfs)
            if self.above_count >= self.activation_frames:
                self.active = True
                self.above_count = 0
                self.below_count = 0
                events.append(VoiceEvent("voice_start", frame.sequence, frame.monotonic_ns, level, threshold))
        else:
            if above:
                self.below_count = 0
            else:
                self.below_count += 1
            if self.below_count >= self.release_frames:
                self.active = False
                self.below_count = 0
                events.append(VoiceEvent("voice_stop", frame.sequence, frame.monotonic_ns, level, threshold))
        return events


class VadService:
    def __init__(self, detector, event_sink):
        self.detector = detector
        self.event_sink = event_sink
        self.frames_processed = 0
        self.processing_errors = 0
        self.last_level_dbfs = -96.0

    def process_frame(self, frame, suppressed=False):
        try:
            self.last_level_dbfs = pcm_rms_dbfs(frame.pcm)
            events = self.detector.process(frame, suppressed=suppressed)
            for event in events:
                self.event_sink.publish(event)
            self.frames_processed += 1
            return events
        except Exception:
            self.processing_errors += 1
            return []

