import queue
import subprocess
import threading
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class MuxResult:
    passed: bool
    output: str | None
    error: str | None


def mux_audio_video(video_path, audio_path, output_path, timeout_s=120.0, runner=subprocess.run):
    video_path = Path(video_path)
    audio_path = Path(audio_path)
    output_path = Path(output_path)
    if not video_path.is_file() or not audio_path.is_file():
        return MuxResult(False, None, "video or audio input is missing")
    temporary = output_path.with_name(f"{output_path.stem}.muxing{output_path.suffix}")
    try:
        runner(
            [
                "ffmpeg", "-y", "-loglevel", "error",
                "-i", str(video_path), "-i", str(audio_path),
                "-map", "0:v:0", "-map", "1:a:0",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "64k",
                "-shortest", "-movflags", "+faststart", str(temporary),
            ],
            check=True,
            timeout=timeout_s,
        )
        temporary.replace(output_path)
        return MuxResult(True, str(output_path), None)
    except Exception as error:
        if temporary.exists():
            temporary.unlink()
        return MuxResult(False, None, str(error))


class AsyncMediaMuxer:
    def __init__(self, mux_function=mux_audio_video):
        self.mux_function = mux_function
        self.jobs = queue.Queue()
        self.results = queue.Queue()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, name="media-muxer", daemon=True)
        self.thread.start()

    def submit(self, video_path, audio_path, output_path):
        self.jobs.put_nowait((video_path, audio_path, output_path))

    def _run(self):
        while not self.stop_event.is_set() or not self.jobs.empty():
            try:
                job = self.jobs.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                self.results.put_nowait(self.mux_function(*job))
            finally:
                self.jobs.task_done()

    def close(self, timeout_s=3.0):
        self.stop_event.set()
        self.thread.join(timeout=timeout_s)

