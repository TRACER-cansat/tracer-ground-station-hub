import threading


class FanoutSink:
    """Publish one real-time sample to independent non-blocking sinks."""

    def __init__(self, sinks=None):
        self._sinks = list(sinks or [])
        self._lock = threading.Lock()
        self.publish_errors = 0

    def add(self, sink):
        with self._lock:
            self._sinks.append(sink)

    def remove(self, sink):
        with self._lock:
            if sink in self._sinks:
                self._sinks.remove(sink)

    def publish(self, item):
        with self._lock:
            sinks = tuple(self._sinks)
        for sink in sinks:
            try:
                sink.publish(item)
            except Exception:
                self.publish_errors += 1


class SwitchableSink:
    def __init__(self):
        self._sink = None
        self._lock = threading.Lock()

    def set_sink(self, sink):
        with self._lock:
            self._sink = sink

    def publish(self, item):
        with self._lock:
            sink = self._sink
        if sink is not None:
            sink.publish(item)


class VadFrameSink:
    def __init__(self, vad_service, suppression_event=None):
        self.vad_service = vad_service
        self.suppression_event = suppression_event

    def publish(self, frame):
        suppressed = self.suppression_event.is_set() if self.suppression_event is not None else False
        self.vad_service.process_frame(frame, suppressed=suppressed)

