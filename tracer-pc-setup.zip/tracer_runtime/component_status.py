from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class ComponentState(str, Enum):
    READY = "ready"
    UNAVAILABLE = "unavailable"
    DEGRADED = "degraded"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass(frozen=True)
class ComponentStatus:
    name: str
    state: ComponentState
    detail: str
    attempts: int = 0
    elapsed_s: float = 0.0
    data: dict[str, Any] | None = None

    @property
    def operational(self) -> bool:
        return self.state in (ComponentState.READY, ComponentState.DEGRADED)

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["state"] = self.state.value
        result["operational"] = self.operational
        return result

