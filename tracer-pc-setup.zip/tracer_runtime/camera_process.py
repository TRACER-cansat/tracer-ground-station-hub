import multiprocessing
import queue
import time
import traceback

from tracer_runtime.component_status import ComponentState, ComponentStatus


def put_latest(channel, value):
    try:
        channel.put_nowait(value)
        return True
    except queue.Full:
        try:
            channel.get_nowait()
        except queue.Empty:
            pass
        try:
            channel.put_nowait(value)
            return True
        except queue.Full:
            return False


def camera_v3_worker(command_queue, status_queue, heartbeat_interval_s=0.5):
    """Run all Picamera2 and HTTP work inside the child process."""
    service = None
    server = None
    try:
        import streaming_back_record_v3_rover as camera_module
        from werkzeug.serving import make_server

        service = camera_module.CameraService()
        camera_module.camera_service = service
        service.start()
        # A process can finish libcamera setup while the capture device is no
        # longer delivering buffers.  Do not advertise it as usable until the
        # MJPEG encoder has produced an actual frame for the ground station.
        sequence = -1
        startup_deadline = time.monotonic() + 5.0
        while time.monotonic() < startup_deadline:
            sequence, frame = service.stream_output.wait_for_frame(sequence, timeout=0.5)
            if frame:
                break
        else:
            raise RuntimeError("camera started but no video frames arrived within 5 seconds")
        server = make_server(camera_module.HOST, camera_module.PORT, camera_module.app, threaded=True)
        server.timeout = 0.02
        put_latest(status_queue, {"event": "ready", "status": service.status()})
        next_heartbeat = time.monotonic()
        running = True
        while running:
            server.handle_request()
            while True:
                try:
                    command = command_queue.get_nowait()
                except queue.Empty:
                    break
                name = command.get("name")
                request_id = command.get("request_id")
                try:
                    if name == "record_start":
                        result = service.start_recording()
                    elif name == "record_stop":
                        result = service.stop_recording()
                    elif name == "exposure_toggle":
                        result = service.toggle_exposure_mode()
                    elif name == "shutdown":
                        running = False
                        result = None
                    else:
                        raise ValueError(f"unknown camera command: {name}")
                    put_latest(status_queue, {"event": "command_ok", "command": name,
                                              "request_id": request_id,
                                              "result": str(result) if result is not None else None,
                                              "status": service.status()})
                except Exception as error:
                    put_latest(status_queue, {"event": "command_error", "command": name,
                                              "request_id": request_id, "error": str(error)})
            now = time.monotonic()
            if now >= next_heartbeat:
                put_latest(status_queue, {"event": "heartbeat", "status": service.status(), "monotonic": now})
                next_heartbeat = now + heartbeat_interval_s
    except BaseException as error:
        put_latest(status_queue, {
            "event": "fatal_error",
            "error": str(error) or type(error).__name__,
            "traceback": traceback.format_exc(limit=4),
        })
    finally:
        if server is not None:
            server.server_close()
        if service is not None:
            try:
                service.close()
            except Exception as error:
                put_latest(status_queue, {"event": "close_error", "error": str(error)})
        put_latest(status_queue, {"event": "stopped"})


class CameraProcessController:
    def __init__(self, worker_target=camera_v3_worker, context=None, command_queue_size=32):
        self.context = context or multiprocessing.get_context("spawn")
        self.worker_target = worker_target
        self.command_queue_size = command_queue_size
        self.command_queue = None
        self.status_queue = None
        self.process = None
        self.last_event = None
        self.last_error = None
        self.request_sequence = 0
        self.pending_events = []
        self.status = ComponentStatus("camera_process", ComponentState.STOPPED, "not started")

    def start(self, timeout_s=8.0):
        if self.process is not None and self.process.is_alive():
            return self.status
        self.command_queue = self.context.Queue(maxsize=self.command_queue_size)
        self.status_queue = self.context.Queue(maxsize=64)
        self.process = self.context.Process(
            target=self.worker_target,
            args=(self.command_queue, self.status_queue),
            name="tracer-camera",
            daemon=True,
        )
        self.process.start()
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            if not self.process.is_alive() and self.status_queue.empty():
                break
            try:
                event = self.status_queue.get(timeout=min(0.1, max(0.0, deadline - time.monotonic())))
            except queue.Empty:
                continue
            self.last_event = event
            if event.get("event") == "ready":
                self.status = ComponentStatus("camera_process", ComponentState.READY, "child process ready", data=event)
                return self.status
            if event.get("event") in ("startup_error", "fatal_error"):
                self.last_error = event
                self.status = ComponentStatus(
                    "camera_process", ComponentState.UNAVAILABLE,
                    f"startup error: {event.get('error')}; continuing without camera",
                    data=event,
                )
                self._finish_failed_start()
                return self.status
        self.status = ComponentStatus(
            "camera_process", ComponentState.UNAVAILABLE,
            "startup timed out; continuing without camera",
        )
        self._finish_failed_start()
        return self.status

    def _finish_failed_start(self):
        if self.process is None:
            return
        self.process.join(timeout=0.2)
        if self.process.is_alive():
            self.process.terminate()
            self.process.join(timeout=1.0)

    def send(self, name, **data):
        if self.process is None or not self.process.is_alive():
            return False
        try:
            self.command_queue.put_nowait({"name": name, **data})
            return True
        except queue.Full:
            return False

    def send_request(self, name, timeout_s=2.0, **data):
        self.request_sequence += 1
        request_id = self.request_sequence
        if not self.send(name, request_id=request_id, **data):
            return None
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            try:
                event = self.status_queue.get(timeout=min(0.05, deadline - time.monotonic()))
            except queue.Empty:
                continue
            self.last_event = event
            if event.get("request_id") == request_id:
                return event
            self.pending_events.append(event)
        return None

    def poll_events(self):
        events = self.pending_events
        self.pending_events = []
        if self.status_queue is None:
            return events
        while True:
            try:
                event = self.status_queue.get_nowait()
            except queue.Empty:
                break
            self.last_event = event
            if event.get("event") in ("startup_error", "fatal_error", "close_error"):
                self.last_error = event
            events.append(event)
        return events

    def restart(self, timeout_s=8.0):
        """Start a fresh child after an unexpected camera-process exit."""
        if self.process is not None and self.process.is_alive():
            return self.status
        self.command_queue = None
        self.status_queue = None
        self.pending_events = []
        self.last_error = None
        return self.start(timeout_s=timeout_s)

    def failure_detail(self):
        event = self.last_error or {}
        if event.get("error"):
            return event["error"]
        if self.process is not None and self.process.exitcode is not None:
            return f"camera child exited with code {self.process.exitcode}"
        return self.status.detail

    def stop(self, timeout_s=3.0):
        if self.process is None:
            return
        if self.process.is_alive():
            self.send("shutdown")
            self.process.join(timeout=timeout_s)
        if self.process.is_alive():
            self.process.terminate()
            self.process.join(timeout=1.0)
        self.status = ComponentStatus("camera_process", ComponentState.STOPPED, "stopped")
