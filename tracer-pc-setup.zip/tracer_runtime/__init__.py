"""Reusable runtime services for the staged TRACER integration."""

