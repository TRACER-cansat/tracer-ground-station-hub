import queue
import threading


class LatestQueue:
    """Bounded non-blocking channel that preserves the newest observations."""

    def __init__(self, maxsize=128):
        if maxsize <= 0:
            raise ValueError("maxsize must be positive")
        self._queue = queue.Queue(maxsize=maxsize)
        self._lock = threading.Lock()
        self.dropped = 0

    def publish(self, item):
        with self._lock:
            if self._queue.full():
                try:
                    self._queue.get_nowait()
                    self._queue.task_done()
                    self.dropped += 1
                except queue.Empty:
                    pass
            self._queue.put_nowait(item)

    def get(self, timeout=None):
        return self._queue.get(timeout=timeout)

    def get_nowait(self):
        return self._queue.get_nowait()

    def task_done(self):
        self._queue.task_done()

    def qsize(self):
        return self._queue.qsize()

