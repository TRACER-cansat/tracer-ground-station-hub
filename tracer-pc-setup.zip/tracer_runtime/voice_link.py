"""Low-latency TCP talkback link for the rover's analog microphone.

The listener is deliberately loopback-only.  It is exposed to the operator
through an SSH ``-L 50100:127.0.0.1:50100`` forward, never directly over Wi-Fi.
"""

import queue
import socket
import struct
import subprocess
import threading
import time
from array import array
import sys

from tracer_runtime.audio_capture import FRAME_BYTES, SAMPLE_RATE
from tracer_runtime.bounded_channel import LatestQueue


MAGIC = b"Z2W1"
HEADER = struct.Struct("!4sIHH")
SAMPLE_BYTES = 2


def _put_latest(channel, value):
    try:
        channel.put_nowait(value)
    except queue.Full:
        try:
            channel.get_nowait()
        except queue.Empty:
            pass
        try:
            channel.put_nowait(value)
        except queue.Full:
            pass


def _encode(sequence, pcm):
    return HEADER.pack(MAGIC, sequence & 0xFFFFFFFF, SAMPLE_RATE,
                       len(pcm) // SAMPLE_BYTES) + pcm


def _read_exact(sock, size, stop):
    data = bytearray()
    while len(data) < size and not stop.is_set():
        try:
            chunk = sock.recv(size - len(data))
        except socket.timeout:
            continue
        if not chunk:
            raise EOFError("voice client disconnected")
        data.extend(chunk)
    return bytes(data)


class AplayPcmSink:
    def __init__(self, device="default"):
        self.device = device
        self.process = None

    def open(self):
        self.process = subprocess.Popen(
            ["aplay", "-q", "-D", self.device, "-t", "raw", "-f", "S16_LE",
             "-c", "1", "-r", str(SAMPLE_RATE), "-"],
            stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
            bufsize=0,
        )

    def write(self, pcm):
        if self.process is None or self.process.stdin is None:
            raise OSError("rover audio playback is not available")
        if self.process.poll() is not None:
            detail = self.process.stderr.read().decode(errors="replace").strip() if self.process.stderr else ""
            raise OSError(detail or "rover audio playback is not available")
        self.process.stdin.write(pcm)

    def close(self):
        if self.process is None:
            return
        if self.process.stdin is not None:
            try:
                self.process.stdin.close()
            except OSError:
                pass
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                self.process.kill()
        self.process = None


class GpioPwmPcmSink:
    """Stream PCM to the GPIO12 speaker using the existing WAV PWM wiring."""

    def __init__(self, device="gpio12-pwm"):
        self.pin = 12
        self.pi = None
        self.next_sample = None

    def open(self):
        import pigpio
        self.pi = pigpio.pi()
        if not self.pi.connected:
            self.pi.stop()
            try:
                subprocess.run(["sudo", "-n", "pigpiod"], check=False,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                pass
            self.pi = pigpio.pi()
            if not self.pi.connected:
                self.pi.stop()
                self.pi = None
                raise OSError("pigpio daemon is unavailable; start pigpiod on the rover")
        self.pi.hardware_PWM(self.pin, 100000, 0)
        self.next_sample = time.monotonic()

    def write(self, pcm):
        samples = array('h')
        samples.frombytes(pcm)
        if sys.byteorder != 'little':
            samples.byteswap()
        period = 1 / SAMPLE_RATE
        for sample in samples:
            now = time.monotonic()
            if now - self.next_sample > .08:
                self.next_sample = now
            if self.next_sample > now:
                time.sleep(self.next_sample - now)
            # Match mic_record_wav_pwm.py's 15% ceiling without per-file normalization.
            duty = max(0, min(150000, int((sample + 32768) * 150000 / 65535)))
            self.pi.hardware_PWM(self.pin, 100000, duty)
            self.next_sample += period

    def close(self):
        if self.pi is not None:
            self.pi.hardware_PWM(self.pin, 0, 0)
            self.pi.stop()
            self.pi = None


class VoiceLinkServer:
    """One full-duplex operator connection; all queues discard stale audio."""

    def __init__(self, speaker_device="default", host="127.0.0.1", port=50100,
                 sink_factory=AplayPcmSink):
        self.host, self.port = host, port
        self.speaker_device = speaker_device
        self.sink_factory = sink_factory
        self.outgoing = LatestQueue(8)
        self.incoming = queue.Queue(maxsize=8)
        self.stop_event = threading.Event()
        self.thread = None
        self.client_connected = threading.Event()
        self.status = "not started"
        self.errors = 0

    def publish(self, frame):
        self.outgoing.publish(frame)

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._serve, name="voice-link", daemon=True)
        self.thread.start()

    def _serve(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                listener.bind((self.host, self.port))
                listener.listen(1)
                listener.settimeout(.5)
                self.status = f"waiting on {self.host}:{self.port}"
                while not self.stop_event.is_set():
                    try:
                        client, _address = listener.accept()
                    except socket.timeout:
                        continue
                    self._run_client(client)
        except Exception as error:
            self.status = f"unavailable: {error}"
            self.errors += 1

    def _run_client(self, client):
        session_stop = threading.Event()
        failures = []
        self.client_connected.set()
        self.status = "operator connected"
        client.settimeout(.2)
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

        def sender():
            sequence = 0
            while not self.stop_event.is_set() and not session_stop.is_set():
                try:
                    frame = self.outgoing.get(timeout=.2)
                except queue.Empty:
                    continue
                try:
                    client.sendall(_encode(sequence, frame.pcm))
                    sequence += 1
                except OSError:
                    session_stop.set()

        def receiver():
            while not self.stop_event.is_set() and not session_stop.is_set():
                try:
                    header = _read_exact(client, HEADER.size, session_stop)
                    magic, _sequence, rate, samples = HEADER.unpack(header)
                    if magic != MAGIC or rate != SAMPLE_RATE or samples * SAMPLE_BYTES != FRAME_BYTES:
                        raise ValueError("invalid operator audio frame")
                    _put_latest(self.incoming, _read_exact(client, samples * SAMPLE_BYTES, session_stop))
                except (EOFError, OSError, ValueError):
                    session_stop.set()

        def playback():
            factory = GpioPwmPcmSink if self.speaker_device == "gpio12-pwm" else self.sink_factory
            sink = factory(self.speaker_device)
            try:
                sink.open()
                silence = bytes(FRAME_BYTES)
                while not self.stop_event.is_set() and not session_stop.is_set():
                    try:
                        pcm = self.incoming.get(timeout=.02)
                    except queue.Empty:
                        pcm = silence
                    sink.write(pcm)
            except Exception as error:
                self.errors += 1
                failures.append(str(error))
                session_stop.set()
            finally:
                sink.close()

        threads = [threading.Thread(target=sender, daemon=True),
                   threading.Thread(target=receiver, daemon=True),
                   threading.Thread(target=playback, daemon=True)]
        for thread in threads:
            thread.start()
        while not self.stop_event.wait(.1) and not session_stop.is_set():
            pass
        session_stop.set()
        try:
            client.close()
        except OSError:
            pass
        for thread in threads:
            thread.join(timeout=.5)
        self.client_connected.clear()
        self.status = f"playback error: {failures[-1]}" if failures else "waiting for operator"

    def close(self):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=2)
        self.thread = None
        self.client_connected.clear()
        self.status = "stopped"
