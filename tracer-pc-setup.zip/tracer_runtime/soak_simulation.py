import json
import math
import statistics
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from tracer_runtime.component_status import ComponentState, ComponentStatus


@dataclass
class SoakReport:
    duration_s: float
    interval_s: float
    expected_ticks: int
    completed_ticks: int
    control_ticks: int
    gnss_ticks: int
    media_ticks: int
    emergency_stops: int
    injected_faults: int
    max_tick_ms: float
    p99_tick_ms: float
    passed: bool
    failures: list[str]

    def write_json(self, path):
        Path(path).write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")


class VirtualClock:
    def __init__(self): self.now = 0.0
    def monotonic(self): return self.now
    def advance(self, seconds): self.now += seconds


class SoakControl:
    def __init__(self, fail_ticks=None):
        self.fail_ticks = set(fail_ticks or ())
        self.ticks = 0
        self.emergency_stops = 0
        self.commands = 0

    def start(self, timeout_s): return ComponentStatus("control", ComponentState.READY, "simulation")
    def tick(self, _now=None):
        self.ticks += 1
        if self.ticks in self.fail_ticks:
            raise RuntimeError("injected control fault")
        return ComponentStatus("control", ComponentState.READY, "simulation")
    def command(self, _action, _value=None): self.commands += 1
    def emergency_stop(self): self.emergency_stops += 1
    def close(self): pass


class SoakGnss:
    def __init__(self, fault_ranges=None):
        self.fault_ranges = tuple(fault_ranges or ())
        self.ticks = 0
    def tick(self, _now=None):
        self.ticks += 1
        if any(start <= self.ticks < end for start, end in self.fault_ranges):
            raise RuntimeError("injected GNSS disconnect")
        return ComponentStatus("gnss", ComponentState.READY, "simulation")
    def close(self): pass


class SoakMedia:
    def __init__(self, fault_ranges=None):
        self.fault_ranges = tuple(fault_ranges or ())
        self.ticks = 0
        self.speaker = None
    def start(self, camera_timeout_s, microphone_timeout_s):
        return ComponentStatus("media", ComponentState.READY, "simulation")
    def capture_audio_once(self, timeout_s):
        self.ticks += 1
        if any(start <= self.ticks < end for start, end in self.fault_ranges):
            raise RuntimeError("injected media disconnect")
    def tick(self, _now=None):
        self.capture_audio_once(0.0)
        return ComponentStatus("media", ComponentState.READY, "simulation")
    def start_recording(self, _name=None): pass
    def stop_recording(self): pass
    def close(self): pass


def percentile(values, percentage):
    if not values: return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, math.ceil(len(ordered) * percentage) - 1)
    return ordered[index]


def run_accelerated_soak(supervisor_factory, duration_s=3600.0, interval_s=0.01,
                         max_tick_ms=10.0):
    expected = int(round(duration_s / interval_s))
    control_fault_tick = max(2, expected // 3)
    gnss_range = (max(2, expected // 4), max(3, expected // 4 + 500))
    media_range = (max(2, expected // 2), max(3, expected // 2 + 500))
    clock = VirtualClock()
    control = SoakControl({control_fault_tick})
    gnss = SoakGnss([gnss_range])
    media = SoakMedia([media_range])
    supervisor = supervisor_factory(control, gnss, media, clock.monotonic)
    supervisor.start(timeout_s=0.2)
    timings = []
    failures = []
    try:
        for _ in range(expected):
            began = time.perf_counter_ns()
            supervisor.tick(clock.monotonic())
            timings.append((time.perf_counter_ns() - began) / 1_000_000)
            clock.advance(interval_s)
        deadline = time.monotonic() + 0.5
        while control.emergency_stops == 0 and time.monotonic() < deadline:
            time.sleep(0.001)
    finally:
        supervisor.close()

    if control.ticks != expected: failures.append("control cadence lost")
    if gnss.ticks != expected: failures.append("GNSS cadence lost")
    if media.ticks != expected: failures.append("media cadence lost")
    if control.emergency_stops < 1: failures.append("control fault did not trigger emergency stop")
    measured_max = max(timings, default=0.0)
    measured_p99 = percentile(timings, 0.99)
    if measured_p99 > max_tick_ms: failures.append(f"p99 tick {measured_p99:.3f}ms exceeded {max_tick_ms}ms")
    return SoakReport(duration_s, interval_s, expected, len(timings), control.ticks,
                      gnss.ticks, media.ticks, control.emergency_stops,
                      1 + (gnss_range[1] - gnss_range[0]) + (media_range[1] - media_range[0]),
                      measured_max, measured_p99, not failures, failures)
