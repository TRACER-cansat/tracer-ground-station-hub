import itertools
import os
import platform
import queue
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from tracer_runtime.bounded_channel import LatestQueue
from tracer_runtime.component_status import ComponentState, ComponentStatus


@dataclass(order=True)
class RoutedCommand:
    priority: int
    sequence: int
    target: str = field(compare=False)
    action: str = field(compare=False)
    value: str | None = field(default=None, compare=False)
    submitted_ns: int = field(default_factory=time.monotonic_ns, compare=False)


class AsyncCommandRouter:
    """Runs potentially slow commands away from the measurement loop."""

    def __init__(self, dispatcher, events, max_queue=128, command_timeout_s=0.25):
        self.dispatcher = dispatcher
        self.events = events
        self.commands = queue.PriorityQueue(maxsize=max_queue)
        self.command_timeout_s = command_timeout_s
        self.stop_event = threading.Event()
        self.thread = None
        self.sequence = itertools.count()
        self.dropped = 0

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, name="system-command-router", daemon=True)
            self.thread.start()

    def submit(self, target, action, value=None, emergency=False):
        command = RoutedCommand(0 if emergency else 10, next(self.sequence), target, action, value)
        try:
            self.commands.put_nowait(command)
            return True
        except queue.Full:
            if not emergency:
                self.dropped += 1
                return False
            try:
                self.commands.get_nowait()
                self.commands.task_done()
                self.dropped += 1
                self.commands.put_nowait(command)
                return True
            except queue.Empty:
                return False

    def _execute_bounded(self, command):
        result = queue.Queue(maxsize=1)

        def invoke():
            try:
                self.dispatcher(command)
                result.put_nowait((True, None))
            except Exception as error:
                result.put_nowait((False, str(error)))

        worker = threading.Thread(target=invoke, name="bounded-command", daemon=True)
        worker.start()
        worker.join(self.command_timeout_s)
        latency_ms = (time.monotonic_ns() - command.submitted_ns) / 1_000_000
        if worker.is_alive():
            self.events.publish({"event": "command_timeout", "target": command.target,
                                 "action": command.action, "latency_ms": latency_ms})
            return
        ok, error = result.get_nowait()
        self.events.publish({"event": "command_ok" if ok else "command_error",
                             "target": command.target, "action": command.action,
                             "error": error, "latency_ms": latency_ms})

    def _run(self):
        while not self.stop_event.is_set() or not self.commands.empty():
            try:
                command = self.commands.get(timeout=0.02)
            except queue.Empty:
                continue
            try:
                self._execute_bounded(command)
            finally:
                self.commands.task_done()

    def close(self, timeout_s=1.0):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout_s)


def _bounded_start(name, function, timeout_s, output):
    def invoke():
        try:
            output.put_nowait((name, function(), None))
        except Exception as error:
            output.put_nowait((name, None, error))

    thread = threading.Thread(target=invoke, name=f"start-{name}", daemon=True)
    thread.start()
    return thread


class SystemSupervisor:
    """Failure-isolated supervisor for Step 7 control, GNSS and media services."""

    def __init__(self, control, gnss, media, events=None, clock=time.monotonic):
        self.control = control
        self.gnss = gnss
        self.media = media
        self.events = events or LatestQueue(256)
        self.clock = clock
        self.statuses = {}
        self.router = AsyncCommandRouter(self._dispatch, self.events)
        self.started = False

    def start(self, timeout_s=3.0):
        output = queue.Queue()
        starters = {
            "control": lambda: self.control.start(timeout_s=timeout_s),
            "gnss": lambda: self.gnss.start(timeout_s=timeout_s) if hasattr(self.gnss, "start")
            else ComponentStatus("gnss", ComponentState.DEGRADED, "reconnect service scheduled"),
            "media": lambda: self.media.start(camera_timeout_s=timeout_s, microphone_timeout_s=timeout_s),
        }
        threads = {name: _bounded_start(name, function, timeout_s, output)
                   for name, function in starters.items()}
        deadline = self.clock() + timeout_s
        pending = set(threads)
        while pending and self.clock() < deadline:
            try:
                name, status, error = output.get(timeout=min(0.02, max(0.0, deadline - self.clock())))
            except queue.Empty:
                continue
            pending.discard(name)
            self.statuses[name] = status if error is None else ComponentStatus(
                name, ComponentState.ERROR, f"startup error: {error}")
        for name in pending:
            self.statuses[name] = ComponentStatus(name, ComponentState.UNAVAILABLE,
                                                   f"startup exceeded {timeout_s:.2f}s")
        self.router.start()
        self.started = True
        state = ComponentState.READY if self.statuses["control"].operational else ComponentState.DEGRADED
        return ComponentStatus("system", state, ", ".join(
            f"{name}={status.state.value}" for name, status in sorted(self.statuses.items())))

    def submit(self, target, action, value=None):
        emergency = target == "control" and action == "emergency_stop"
        return self.router.submit(target, action, value, emergency=emergency)

    def _dispatch(self, command):
        if command.target == "control":
            if command.action == "emergency_stop":
                return self.control.emergency_stop()
            return self.control.command(command.action, command.value)
        if command.target == "media":
            if command.action == "record_start":
                return self.media.start_recording(command.value)
            if command.action == "record_stop":
                return self.media.stop_recording()
        if command.target == "speaker" and self.media.speaker is not None:
            return self.media.speaker.submit(command.action, command.value)
        raise ValueError(f"unsupported command {command.target}:{command.action}")

    def tick(self, now=None):
        now = self.clock() if now is None else now
        try:
            self.statuses["control"] = self.control.tick(now)
        except Exception as error:
            self.statuses["control"] = ComponentStatus("control", ComponentState.ERROR, str(error))
            self.submit("control", "emergency_stop")
        try:
            self.statuses["gnss"] = self.gnss.tick(now)
        except Exception as error:
            self.statuses["gnss"] = ComponentStatus("gnss", ComponentState.ERROR, str(error))
        try:
            if hasattr(self.media, "tick"):
                self.statuses["media"] = self.media.tick(now)
            else:
                self.media.capture_audio_once(timeout_s=0.0)
        except Exception as error:
            self.statuses["media"] = ComponentStatus("media", ComponentState.DEGRADED, str(error))
        return dict(self.statuses)

    def close(self):
        # Motion is stopped before recorders and sensors are closed.
        try:
            self.control.emergency_stop()
        except Exception:
            pass
        self.router.close()
        for name, service, method in (
            ("media", self.media, "close"), ("gnss", self.gnss, "close"),
            ("control", self.control, "close")):
            try:
                getattr(service, method)()
            except Exception as error:
                self.events.publish({"event": "shutdown_error", "component": name, "error": str(error)})
        self.started = False


class LegacyStep7Process:
    """Runs the existing Step 7 script in a PTY so commands remain external."""

    KEY_MAP = {"forward": "w", "left": "a", "right": "d", "back": "s",
               "brake": "b", "led": "e", "stop": " ", "quit": "q"}

    def __init__(self, script="drive.py",
                 log_path="step11_control.log"):
        self.script = Path(script)
        self.log_path = Path(log_path)
        self.process = None
        self.master_fd = None
        self.log_file = None

    def start(self, timeout_s=3.0):
        if platform.system() != "Linux":
            return ComponentStatus("control", ComponentState.UNAVAILABLE, "Step 7 PTY requires Linux")
        import pty
        self.master_fd, slave_fd = pty.openpty()
        self.log_file = self.log_path.open("ab", buffering=0)
        self.process = subprocess.Popen(
            [sys.executable, "-u", str(self.script)], stdin=slave_fd,
            stdout=self.log_file, stderr=subprocess.STDOUT, close_fds=True,
            env=self.child_environment(),
        )
        os.close(slave_fd)
        time.sleep(min(0.1, timeout_s))
        state = ComponentState.READY if self.process.poll() is None else ComponentState.ERROR
        return ComponentStatus("control", state, "Step 7 child process started" if state == ComponentState.READY
                               else f"Step 7 exited with {self.process.returncode}")

    @staticmethod
    def child_environment():
        environment = os.environ.copy()
        environment["TRACER_DISABLE_INTERNAL_GNSS"] = "1"
        return environment

    def command(self, action, _value=None):
        key = self.KEY_MAP.get(action, action if len(action) == 1 else None)
        if key is None or self.master_fd is None:
            raise ValueError(f"unsupported control action: {action}")
        os.write(self.master_fd, key.encode())

    def emergency_stop(self):
        if self.master_fd is not None:
            os.write(self.master_fd, b" ")

    def tick(self, _now=None):
        if self.process is None:
            return ComponentStatus("control", ComponentState.STOPPED, "not started")
        if self.process.poll() is None:
            return ComponentStatus("control", ComponentState.READY, "Step 7 process running")
        return ComponentStatus("control", ComponentState.ERROR, f"Step 7 exited with {self.process.returncode}")

    def close(self):
        if self.process is not None and self.process.poll() is None:
            try:
                self.command("quit")
                self.process.wait(timeout=2.0)
            except Exception:
                self.process.terminate()
                try:
                    self.process.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    self.process.kill()
        if self.master_fd is not None:
            os.close(self.master_fd)
            self.master_fd = None
        if self.log_file is not None:
            self.log_file.close()
            self.log_file = None
