import select
import re
import subprocess
import threading
import time
import wave
from dataclasses import dataclass

from tracer_runtime.component_status import ComponentState, ComponentStatus


# The rover's microphone is an AE-MICAMP connected to MCP3204 CH0.  The
# existing voice endpoint supplied with the rover samples it at 8 kHz, which
# is sufficient for speech and keeps SPI/CPU use low on the Zero 2 W.
SAMPLE_RATE = 8_000
CHANNELS = 1
SAMPLE_WIDTH_BYTES = 2
FRAME_DURATION_MS = 20
SAMPLES_PER_FRAME = SAMPLE_RATE * FRAME_DURATION_MS // 1000
FRAME_BYTES = SAMPLES_PER_FRAME * CHANNELS * SAMPLE_WIDTH_BYTES


@dataclass(frozen=True)
class AudioFrame:
    sequence: int
    monotonic_ns: int
    pcm: bytes


class ArecordBackend:
    def __init__(self, device="default", startup_grace_s=0.05, sleeper=time.sleep):
        self.device = device
        self.startup_grace_s = startup_grace_s
        self.sleeper = sleeper
        self.process = None
        self.last_error = ""

    def open(self):
        self.process = subprocess.Popen(
            [
                "arecord", "-q", "-D", self.device,
                "-f", "S16_LE", "-r", str(SAMPLE_RATE),
                "-c", str(CHANNELS), "-t", "raw",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=0,
        )
        self.sleeper(self.startup_grace_s)
        if self.process.poll() is None:
            return True
        if self.process.stderr is not None:
            try:
                self.last_error = self.process.stderr.read(2048).decode(errors="replace").strip()
            except Exception:
                pass
        return False

    def read_frame(self, timeout_s):
        if self.process is None or self.process.stdout is None:
            raise RuntimeError("microphone backend is not open")
        readable, _, _ = select.select([self.process.stdout], [], [], timeout_s)
        if not readable:
            raise TimeoutError("microphone frame timeout")
        data = self.process.stdout.read(FRAME_BYTES)
        if len(data) != FRAME_BYTES:
            error = ""
            if self.process.stderr is not None:
                try:
                    error = self.process.stderr.read1(1024).decode(errors="replace")
                except Exception:
                    pass
            raise OSError(error.strip() or f"short microphone frame: {len(data)} bytes")
        return data

    def close(self):
        if self.process is None:
            return
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1.0)
        self.process = None


def discover_capture_devices(command_runner=subprocess.run):
    """Return ALSA hardware capture devices as stable plughw addresses."""
    try:
        result = command_runner(["arecord", "-l"], capture_output=True, text=True,
                                timeout=2, check=False)
    except (OSError, subprocess.SubprocessError):
        return []
    devices = []
    for card, device in re.findall(r"card\s+(\d+):.*?device\s+(\d+):", result.stdout):
        address = f"plughw:{card},{device}"
        if address not in devices:
            devices.append(address)
    return devices


class AutoArecordBackend:
    """Prefer a real ALSA capture device and rediscover it on every open."""
    def __init__(self, preferred_device="auto", discovery=discover_capture_devices,
                 backend_class=ArecordBackend):
        self.preferred_device = preferred_device
        self.discovery = discovery
        self.backend_class = backend_class
        self.backend = None
        self.device = None
        self.last_error = ""

    def open(self):
        candidates = list(self.discovery())
        if self.preferred_device not in (None, "", "auto"):
            candidates.append(self.preferred_device)
        if not candidates:
            self.last_error = "no ALSA capture device detected; connect a USB/I2S microphone"
            return False
        errors = []
        for device in dict.fromkeys(candidates):
            backend = self.backend_class(device)
            try:
                if backend.open():
                    self.backend = backend
                    self.device = device
                    return True
                errors.append(f"{device}: {backend.last_error or 'did not open'}")
            except Exception as error:
                errors.append(f"{device}: {error}")
            try:
                backend.close()
            except Exception:
                pass
        self.last_error = "; ".join(errors) or "microphone did not open"
        return False

    def read_frame(self, timeout_s):
        if self.backend is None:
            raise RuntimeError("microphone backend is not open")
        return self.backend.read_frame(timeout_s)

    def close(self):
        if self.backend is not None:
            self.backend.close()
        self.backend = None


class Mcp3204MicrophoneBackend:
    """PCM capture backend for an analog microphone on MCP3204 channel 0.

    It uses the same SPI0/CE0 converter as the battery monitor, but keeps its
    own file handle.  Linux serializes each SPI transfer, so a battery sample
    can only delay one audio sample; stale audio is never buffered here.
    """

    def __init__(self, channel=0, bus=0, device=0, speed_hz=1_000_000,
                 center=2048.0, gain=18.0, dc_seconds=1.0, invert=False,
                 clock=time.perf_counter, sleeper=time.sleep):
        self.channel = channel
        self.bus = bus
        self.device = device
        self.speed_hz = speed_hz
        self.center = float(center)
        self.gain = float(gain)
        self.dc_seconds = float(dc_seconds)
        self.invert = invert
        self.clock = clock
        self.sleeper = sleeper
        self.spi = None
        self.last_error = ""
        self.next_sample_at = None

    def open(self):
        if not 0 <= self.channel <= 3:
            self.last_error = "MCP3204 microphone channel must be 0-3"
            return False
        try:
            import spidev
            spi = spidev.SpiDev()
            spi.open(self.bus, self.device)
            spi.max_speed_hz = self.speed_hz
            spi.mode = 0
            self.spi = spi
            self.next_sample_at = self.clock()
            return True
        except Exception as error:
            self.last_error = f"MCP3204 microphone unavailable: {error}"
            self.close()
            return False

    def _read_raw(self):
        if self.spi is None:
            raise RuntimeError("MCP3204 microphone is not open")
        response = self.spi.xfer2([0x06, (self.channel & 0x03) << 6, 0x00])
        return ((response[1] & 0x0F) << 8) | response[2]

    @staticmethod
    def _clamp_i16(value):
        return max(-32768, min(32767, int(value)))

    def read_frame(self, _timeout_s):
        if self.next_sample_at is None:
            raise RuntimeError("MCP3204 microphone is not open")
        import struct
        period = 1.0 / SAMPLE_RATE
        alpha = 1.0 / max(1.0, self.dc_seconds * SAMPLE_RATE)
        output = bytearray(FRAME_BYTES)
        for index in range(SAMPLES_PER_FRAME):
            raw = self._read_raw()
            self.center += (raw - self.center) * alpha
            value = (raw - self.center) * self.gain
            if self.invert:
                value = -value
            struct.pack_into("<h", output, index * SAMPLE_WIDTH_BYTES,
                             self._clamp_i16(value))
            self.next_sample_at += period
            delay = self.next_sample_at - self.clock()
            if delay > 0.0005:
                self.sleeper(delay - 0.0002)
            while self.clock() < self.next_sample_at:
                pass
        if self.clock() - self.next_sample_at > FRAME_DURATION_MS / 1000:
            self.next_sample_at = self.clock()
        return bytes(output)

    def close(self):
        if self.spi is not None:
            try:
                self.spi.close()
            finally:
                self.spi = None
        self.next_sample_at = None


class MicrophoneCaptureService:
    def __init__(self, backend_factory, frame_sink, clock_ns=time.monotonic_ns):
        self.backend_factory = backend_factory
        self.frame_sink = frame_sink
        self.clock_ns = clock_ns
        self.backend = None
        self.sequence = 0
        self.frames_captured = 0
        self.read_errors = 0
        self.connection_attempts = 0
        self.status = ComponentStatus("microphone", ComponentState.STOPPED, "not started")

    def connect(self, timeout_s=5.0, retry_interval_s=0.5, clock=time.monotonic, sleeper=time.sleep):
        started = clock()
        deadline = started + timeout_s
        last_error = "microphone not available"
        while True:
            self.connection_attempts += 1
            backend = None
            try:
                backend = self.backend_factory()
                if backend.open():
                    self.backend = backend
                    self.status = ComponentStatus(
                        "microphone", ComponentState.READY, "capture ready",
                        self.connection_attempts, max(0.0, clock() - started),
                    )
                    return self.status
                last_error = getattr(backend, "last_error", "") or "microphone did not open"
            except Exception as error:
                last_error = f"microphone open error: {error}"
            if backend is not None:
                try:
                    backend.close()
                except Exception:
                    pass
            now = clock()
            if now >= deadline:
                self.status = ComponentStatus(
                    "microphone", ComponentState.UNAVAILABLE,
                    f"{last_error}; continuing without microphone",
                    self.connection_attempts, max(0.0, now - started),
                )
                return self.status
            sleeper(min(retry_interval_s, deadline - now))

    def capture_once(self, timeout_s=0.1):
        if self.backend is None:
            return None
        try:
            pcm = self.backend.read_frame(timeout_s)
            if len(pcm) != FRAME_BYTES:
                raise ValueError(f"invalid frame size {len(pcm)}")
            frame = AudioFrame(self.sequence, self.clock_ns(), pcm)
            self.sequence += 1
            self.frames_captured += 1
            self.frame_sink.publish(frame)
            return frame
        except Exception as error:
            self.read_errors += 1
            try:
                self.backend.close()
            except Exception:
                pass
            self.backend = None
            self.status = ComponentStatus(
                "microphone", ComponentState.UNAVAILABLE,
                f"capture error: {error}; reconnect required",
                self.connection_attempts,
            )
            return None

    def close(self):
        if self.backend is not None:
            try:
                self.backend.close()
            finally:
                self.backend = None
        self.status = ComponentStatus("microphone", ComponentState.STOPPED, "stopped")


class AsyncWavWriter:
    def __init__(self, frame_channel, path):
        self.frame_channel = frame_channel
        self.path = path
        self.stop_event = threading.Event()
        self.thread = None
        self.frames_written = 0

    def start(self):
        self.thread = threading.Thread(target=self._run, name="microphone-wav-writer", daemon=True)
        self.thread.start()

    def _run(self):
        with wave.open(str(self.path), "wb") as output:
            output.setnchannels(CHANNELS)
            output.setsampwidth(SAMPLE_WIDTH_BYTES)
            output.setframerate(SAMPLE_RATE)
            while not self.stop_event.is_set() or self.frame_channel.qsize():
                try:
                    frame = self.frame_channel.get(timeout=0.1)
                except Exception:
                    continue
                try:
                    output.writeframesraw(frame.pcm)
                    self.frames_written += 1
                finally:
                    self.frame_channel.task_done()

    def close(self):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=2.0)
