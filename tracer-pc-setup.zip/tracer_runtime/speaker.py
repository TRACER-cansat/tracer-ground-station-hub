import queue
import subprocess
import threading
import time
from pathlib import Path

from tracer_runtime.bounded_channel import LatestQueue


ALLOWED_EXTENSIONS = {".wav"}


class AplayBackend:
    def __init__(self, device="default"):
        self.device = device
        self.process = None

    def play(self, path):
        self.stop()
        self.process = subprocess.Popen(
            ["aplay", "-q", "-D", self.device, str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

    def is_playing(self):
        return self.process is not None and self.process.poll() is None

    def stop(self):
        if self.process is None:
            return
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=0.5)
        self.process = None

    def close(self):
        self.stop()


class SpeakerCommandPlayer:
    def __init__(self, sound_directory, backend, max_queue=32, max_playback_s=30.0, clock=time.monotonic):
        self.sound_directory = Path(sound_directory).resolve()
        self.backend = backend
        self.commands = queue.Queue(maxsize=max_queue)
        self.events = LatestQueue(maxsize=64)
        self.max_playback_s = max_playback_s
        self.clock = clock
        self.stop_event = threading.Event()
        self.playing_event = threading.Event()
        self.thread = None
        self.current_name = None
        self.playback_started = None
        self.command_errors = 0

    def _resolve_sound(self, name):
        if not isinstance(name, str) or not name:
            raise ValueError("sound name is empty")
        candidate = (self.sound_directory / name).resolve()
        try:
            candidate.relative_to(self.sound_directory)
        except ValueError as error:
            raise ValueError("sound path escapes the allowed directory") from error
        if candidate.suffix.lower() not in ALLOWED_EXTENSIONS:
            raise ValueError("sound file extension is not allowed")
        if not candidate.is_file():
            raise FileNotFoundError(candidate)
        return candidate

    def submit(self, name, sound=None):
        try:
            self.commands.put_nowait({"name": name, "sound": sound})
            return True
        except queue.Full:
            return False

    def start(self):
        self.thread = threading.Thread(target=self._run, name="speaker-command-player", daemon=True)
        self.thread.start()

    def _publish(self, event, **data):
        self.events.publish({"event": event, "monotonic": self.clock(), **data})

    def _stop_playback(self, reason="command"):
        if self.playing_event.is_set() or self.backend.is_playing():
            self.backend.stop()
            self._publish("playback_stopped", sound=self.current_name, reason=reason)
        self.playing_event.clear()
        self.current_name = None
        self.playback_started = None

    def process_command(self, command):
        name = command.get("name")
        if name == "play":
            path = self._resolve_sound(command.get("sound"))
            self._stop_playback(reason="replaced")
            self.backend.play(path)
            self.current_name = path.name
            self.playback_started = self.clock()
            self.playing_event.set()
            self._publish("playback_started", sound=path.name)
        elif name == "stop":
            self._stop_playback(reason="command")
        elif name == "shutdown":
            self.stop_event.set()
        else:
            raise ValueError(f"unknown speaker command: {name}")

    def tick(self):
        try:
            command = self.commands.get_nowait()
        except queue.Empty:
            command = None
        if command is not None:
            try:
                self.process_command(command)
                self._publish("command_ok", command=command.get("name"))
            except Exception as error:
                self.command_errors += 1
                self._publish("command_error", command=command.get("name"), error=str(error))
            finally:
                self.commands.task_done()

        if self.playing_event.is_set():
            if not self.backend.is_playing():
                self._publish("playback_finished", sound=self.current_name)
                self.playing_event.clear()
                self.current_name = None
                self.playback_started = None
            elif self.playback_started is not None and self.clock() - self.playback_started >= self.max_playback_s:
                self._stop_playback(reason="timeout")

    def _run(self):
        while not self.stop_event.is_set():
            self.tick()
            self.stop_event.wait(0.02)
        self._stop_playback(reason="shutdown")
        self.backend.close()

    def close(self, timeout_s=2.0):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=timeout_s)
        if self.thread is not None and self.thread.is_alive():
            self.backend.close()

