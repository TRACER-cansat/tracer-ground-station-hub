import threading
import time
from dataclasses import asdict

from gnss_component_step2_positioning import GnssFix
from tracer_runtime.component_status import ComponentState, ComponentStatus


def advance_deadline(previous_deadline, interval, now):
    deadline = previous_deadline + interval
    while deadline <= now:
        deadline += interval
    return deadline


class GnssReconnectService:
    """Non-blocking GNSS sampler with permanent reconnect behavior."""

    def __init__(
        self,
        backend_factory,
        sample_sink,
        sample_interval_s=0.2,
        reconnect_interval_s=2.0,
        minimum_satellites=4,
        clock=time.monotonic,
    ):
        self.backend_factory = backend_factory
        self.sample_sink = sample_sink
        self.sample_interval_s = sample_interval_s
        self.reconnect_interval_s = reconnect_interval_s
        self.minimum_satellites = minimum_satellites
        self.clock = clock
        self.backend = None
        self.connected = False
        self.next_reconnect_at = 0.0
        self.next_sample_at = 0.0
        self.connection_attempts = 0
        self.samples_read = 0
        self.samples_published = 0
        self.last_sample_key = None
        self.status = ComponentStatus("gnss", ComponentState.UNAVAILABLE, "not started")

    def _disconnect(self, detail, now):
        backend = self.backend
        self.backend = None
        self.connected = False
        self.next_reconnect_at = now + self.reconnect_interval_s
        self.status = ComponentStatus(
            "gnss",
            ComponentState.UNAVAILABLE,
            detail,
            self.connection_attempts,
        )
        if backend is not None:
            try:
                backend.close()
            except Exception:
                pass

    def _connect(self, now):
        self.connection_attempts += 1
        try:
            backend = self.backend_factory()
            if not backend.connect():
                try:
                    backend.close()
                except Exception:
                    pass
                self.next_reconnect_at = now + self.reconnect_interval_s
                self.status = ComponentStatus(
                    "gnss", ComponentState.UNAVAILABLE,
                    "device unavailable; reconnect scheduled",
                    self.connection_attempts,
                )
                return
            self.backend = backend
            self.connected = True
            self.next_sample_at = now
            self.status = ComponentStatus(
                "gnss", ComponentState.DEGRADED,
                "connected; waiting for position fix",
                self.connection_attempts,
            )
        except Exception as error:
            self.next_reconnect_at = now + self.reconnect_interval_s
            self.status = ComponentStatus(
                "gnss", ComponentState.UNAVAILABLE,
                f"connect error: {error}; reconnect scheduled",
                self.connection_attempts,
            )

    @staticmethod
    def _sample_key(sample: GnssFix):
        return (sample.utc_iso, sample.latitude_deg, sample.longitude_deg, sample.satellites)

    def tick(self, now=None):
        now = self.clock() if now is None else now
        if not self.connected:
            if now >= self.next_reconnect_at:
                self._connect(now)
            return self.status
        if now < self.next_sample_at:
            return self.status

        self.next_sample_at = advance_deadline(self.next_sample_at, self.sample_interval_s, now)
        try:
            sample = self.backend.read_fix()
            self.samples_read += 1
            key = self._sample_key(sample)
            if key != self.last_sample_key:
                self.sample_sink.publish(sample)
                self.samples_published += 1
                self.last_sample_key = key
            if sample.valid(self.minimum_satellites):
                self.status = ComponentStatus(
                    "gnss", ComponentState.READY,
                    f"tracking {sample.satellites} satellites",
                    self.connection_attempts,
                    data={"fix": asdict(sample)},
                )
            else:
                self.status = ComponentStatus(
                    "gnss", ComponentState.DEGRADED,
                    f"connected without fix ({sample.satellites} satellites)",
                    self.connection_attempts,
                    data={"last_sample": asdict(sample)},
                )
        except Exception as error:
            self._disconnect(f"read error: {error}; reconnect scheduled", now)
        return self.status

    def run(self, stop_event: threading.Event, idle_wait_s=0.02):
        while not stop_event.is_set():
            self.tick()
            stop_event.wait(idle_wait_s)
        self.close()

    def close(self):
        self._disconnect("stopped", self.clock())
        self.status = ComponentStatus("gnss", ComponentState.STOPPED, "stopped")

