"""Background MCP3204 battery voltage monitor for the 2S LiPo pack."""

import threading
import time

from tracer_runtime.component_status import ComponentState, ComponentStatus


# Calibrated against a trusted meter: calculated 8.349 V while meter read 8.120 V.
VREF = 3.326
R1_OHMS = 17_820
R2_OHMS = 9_920
BATTERY_CHANNEL = 2
LOW_WARNING_V = 7.0
LOW_CRITICAL_V = 6.6
SAMPLE_COUNT = 20
SPI_BUS = 0
SPI_DEVICE = 0
SPI_SPEED_HZ = 100_000


class Mcp3204BatteryReader:
    def __init__(self):
        self.spi = None

    def open(self):
        import spidev

        spi = spidev.SpiDev()
        try:
            spi.open(SPI_BUS, SPI_DEVICE)
            spi.max_speed_hz = SPI_SPEED_HZ
            spi.mode = 0b00
            self.spi = spi
        except Exception:
            spi.close()
            raise

    def read_raw(self, channel):
        if not 0 <= channel <= 3:
            raise ValueError("MCP3204 channel must be 0-3")
        if self.spi is None:
            raise RuntimeError("MCP3204 SPI is not open")
        response = self.spi.xfer2([0x06, (channel & 0x03) << 6, 0x00])
        return ((response[1] & 0x0F) << 8) | response[2]

    def read_average(self, channel=BATTERY_CHANNEL, samples=SAMPLE_COUNT):
        if samples <= 0:
            raise ValueError("sample count must be positive")
        self.read_raw(channel)
        time.sleep(0.002)
        values = []
        for _ in range(samples):
            values.append(self.read_raw(channel))
            time.sleep(0.002)
        return sum(values) / len(values)

    @staticmethod
    def raw_to_adc_voltage(raw):
        return raw * VREF / 4095.0

    @staticmethod
    def adc_to_battery_voltage(adc_voltage):
        return adc_voltage * (R1_OHMS + R2_OHMS) / R2_OHMS

    def read(self):
        average_raw = self.read_average()
        adc_voltage = self.raw_to_adc_voltage(average_raw)
        battery_voltage = self.adc_to_battery_voltage(adc_voltage)
        return average_raw, adc_voltage, battery_voltage

    def close(self):
        if self.spi is not None:
            self.spi.close()
            self.spi = None


def judge_battery_status(voltage):
    if voltage <= LOW_CRITICAL_V:
        return ComponentState.DEGRADED, "CRITICAL: stop recommended"
    if voltage <= LOW_WARNING_V:
        return ComponentState.DEGRADED, "LOW"
    return ComponentState.READY, "OK"


class BatteryMonitor:
    """Measure the battery in a worker so SPI sampling never delays controls."""

    def __init__(
        self,
        reader_factory=Mcp3204BatteryReader,
        interval_s=1.0,
        reconnect_interval_s=2.0,
    ):
        self.reader_factory = reader_factory
        self.interval_s = interval_s
        self.reconnect_interval_s = reconnect_interval_s
        self.reader = None
        self.stop_event = threading.Event()
        self.thread = None
        self.status = ComponentStatus(
            "battery", ComponentState.UNAVAILABLE, "not started"
        )

    def start(self):
        if self.thread is not None and self.thread.is_alive():
            return self.status
        self.stop_event.clear()
        self.status = ComponentStatus(
            "battery", ComponentState.UNAVAILABLE, "starting"
        )
        self.thread = threading.Thread(
            target=self._run,
            name="battery-monitor",
            daemon=True,
        )
        self.thread.start()
        return self.status

    def _close_reader(self):
        reader = self.reader
        self.reader = None
        if reader is not None:
            try:
                reader.close()
            except Exception:
                pass

    def _run(self):
        while not self.stop_event.is_set():
            started_at = time.monotonic()
            try:
                if self.reader is None:
                    reader = self.reader_factory()
                    reader.open()
                    self.reader = reader
                raw, adc_voltage, battery_voltage = self.reader.read()
                state, condition = judge_battery_status(battery_voltage)
                self.status = ComponentStatus(
                    "battery",
                    state,
                    f"{battery_voltage:.2f} V ({condition})",
                    data={
                        "raw": raw,
                        "adc_voltage_v": adc_voltage,
                        "battery_voltage_v": battery_voltage,
                        "condition": condition,
                    },
                )
                wait_s = max(0.0, self.interval_s - (time.monotonic() - started_at))
            except Exception as error:
                self._close_reader()
                self.status = ComponentStatus(
                    "battery",
                    ComponentState.UNAVAILABLE,
                    f"read error: {error}; retry scheduled",
                )
                wait_s = self.reconnect_interval_s
            self.stop_event.wait(wait_s)
        self._close_reader()

    def tick(self):
        return self.status

    def close(self):
        self.stop_event.set()
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None
        self._close_reader()
        self.status = ComponentStatus(
            "battery", ComponentState.STOPPED, "stopped"
        )
