import json
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path

from tracer_runtime.bounded_channel import LatestQueue
from tracer_runtime.component_status import ComponentState, ComponentStatus


@dataclass
class MediaSession:
    session_id: str
    started_monotonic_ns: int
    stopped_monotonic_ns: int | None
    camera_requested: bool
    microphone_recording: bool
    audio_file: str | None
    video_file: str | None
    errors: list[str]


class MediaService:
    def __init__(
        self,
        camera_controller,
        microphone,
        recording_sink,
        writer_factory,
        broadcaster=None,
        speaker=None,
        muxer=None,
        sessions_directory="media_sessions",
        clock_ns=time.monotonic_ns,
    ):
        self.camera = camera_controller
        self.microphone = microphone
        self.recording_sink = recording_sink
        self.writer_factory = writer_factory
        self.broadcaster = broadcaster
        self.speaker = speaker
        self.muxer = muxer
        self.sessions_directory = Path(sessions_directory)
        self.clock_ns = clock_ns
        self.camera_status = ComponentStatus("camera_process", ComponentState.STOPPED, "not started")
        self.microphone_status = ComponentStatus("microphone", ComponentState.STOPPED, "not started")
        self.session = None
        self.audio_writer = None
        self.audio_channel = None
        self.audio_stop_event = threading.Event()
        self.audio_thread = None
        self.camera_restart_lock = threading.Lock()
        self.camera_restart_thread = None
        self.next_camera_restart_at = 0.0
        self.camera_restart_attempts = 0
        self.camera_restart_backoff_s = 2.0
        self.camera_restart_timeout_s = 8.0

    def start(self, camera_timeout_s=8.0, microphone_timeout_s=5.0):
        self.camera_restart_timeout_s = camera_timeout_s
        try:
            self.camera_status = self.camera.start(timeout_s=camera_timeout_s)
        except Exception as error:
            self.camera_status = ComponentStatus("camera_process", ComponentState.ERROR, f"camera start error: {error}")
        try:
            self.microphone_status = self.microphone.connect(timeout_s=microphone_timeout_s)
        except Exception as error:
            self.microphone_status = ComponentStatus("microphone", ComponentState.ERROR, f"microphone start error: {error}")
        for optional_service in (self.broadcaster, self.speaker):
            if optional_service is not None:
                try:
                    optional_service.start()
                except Exception:
                    pass
        self.audio_stop_event.clear()
        self.audio_thread = threading.Thread(
            target=self._audio_loop, name="media-audio-capture", daemon=True)
        self.audio_thread.start()
        if self.camera_status.operational and self.microphone_status.operational:
            return ComponentStatus("media", ComponentState.READY, "camera and microphone ready")
        if self.camera_status.operational or self.microphone_status.operational:
            return ComponentStatus(
                "media", ComponentState.DEGRADED,
                f"camera={self.camera_status.state.value}, microphone={self.microphone_status.state.value}",
            )
        return ComponentStatus("media", ComponentState.UNAVAILABLE, "camera and microphone unavailable; control may continue")

    def _audio_loop(self):
        while not self.audio_stop_event.is_set():
            if getattr(self.microphone, "backend", object()) is None:
                self.microphone_status = self.microphone.connect(
                    timeout_s=1.0, retry_interval_s=0.25)
                if not self.microphone_status.operational:
                    self.audio_stop_event.wait(0.5)
                    continue
            frame = self.microphone.capture_once(timeout_s=0.1)
            self.microphone_status = self.microphone.status
            if frame is None:
                self.audio_stop_event.wait(0.05)

    def tick(self, _now=None):
        now = time.monotonic() if _now is None else _now
        if hasattr(self.camera, "poll_events"):
            for event in self.camera.poll_events():
                if event.get("event") in ("startup_error", "fatal_error", "command_error", "close_error"):
                    self.camera_status = ComponentStatus(
                        "camera_process", ComponentState.DEGRADED,
                        event.get("error", event.get("event")), data=event)
        process = getattr(self.camera, "process", None)
        if process is not None and not process.is_alive():
            detail = (self.camera.failure_detail() if hasattr(self.camera, "failure_detail")
                      else "camera process exited")
            self.camera_status = ComponentStatus(
                "camera_process", ComponentState.UNAVAILABLE,
                f"camera process stopped: {detail}; restart scheduled")
            self._schedule_camera_restart(now)
        if self.camera_status.operational and self.microphone_status.operational:
            return ComponentStatus("media", ComponentState.READY, "camera and microphone ready")
        if self.camera_status.operational or self.microphone_status.operational:
            return ComponentStatus(
                "media", ComponentState.DEGRADED,
                f"camera={self.camera_status.state.value}, microphone={self.microphone_status.state.value}")
        return ComponentStatus("media", ComponentState.UNAVAILABLE, "camera and microphone unavailable")

    def _schedule_camera_restart(self, now):
        with self.camera_restart_lock:
            if now < self.next_camera_restart_at:
                return
            if self.camera_restart_thread is not None and self.camera_restart_thread.is_alive():
                return
            self.next_camera_restart_at = now + self.camera_restart_backoff_s
            self.camera_restart_attempts += 1
            self.camera_restart_thread = threading.Thread(
                target=self._restart_camera,
                name="media-camera-restart",
                daemon=True,
            )
            self.camera_restart_thread.start()

    def _restart_camera(self):
        try:
            status = self.camera.restart(timeout_s=self.camera_restart_timeout_s)
        except Exception as error:
            status = ComponentStatus("camera_process", ComponentState.UNAVAILABLE,
                                     f"camera restart error: {error}")
        with self.camera_restart_lock:
            self.camera_status = status
            if status.operational:
                self.camera_restart_attempts = 0
                self.next_camera_restart_at = 0.0
            else:
                self.next_camera_restart_at = time.monotonic() + min(
                    15.0, self.camera_restart_backoff_s * max(1, self.camera_restart_attempts))

    def capture_audio_once(self, timeout_s=0.1):
        if not self.microphone_status.operational:
            return None
        frame = self.microphone.capture_once(timeout_s=timeout_s)
        if frame is None and not self.microphone.status.operational:
            self.microphone_status = self.microphone.status
        return frame

    def start_recording(self, session_id=None):
        if self.session is not None:
            return self.session
        session_id = session_id or datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        directory = self.sessions_directory / session_id
        directory.mkdir(parents=True, exist_ok=True)
        errors = []
        camera_requested = False
        if self.camera_status.operational:
            if hasattr(self.camera, "send_request"):
                response = self.camera.send_request("record_start", timeout_s=2.0)
                camera_requested = bool(response and response.get("event") == "command_ok")
            else:
                camera_requested = self.camera.send("record_start")
            if not camera_requested:
                errors.append("camera record command queue unavailable")
        audio_file = None
        microphone_recording = False
        if self.microphone_status.operational:
            try:
                self.audio_channel = LatestQueue(maxsize=250)
                audio_path = directory / "audio.wav"
                self.audio_writer = self.writer_factory(self.audio_channel, audio_path)
                self.audio_writer.start()
                self.recording_sink.set_sink(self.audio_channel)
                audio_file = str(audio_path)
                microphone_recording = True
            except Exception as error:
                errors.append(f"audio record start error: {error}")
        self.session = MediaSession(
            session_id=session_id,
            started_monotonic_ns=self.clock_ns(),
            stopped_monotonic_ns=None,
            camera_requested=camera_requested,
            microphone_recording=microphone_recording,
            audio_file=audio_file,
            video_file=None,
            errors=errors,
        )
        self._write_manifest(directory)
        return self.session

    def _write_manifest(self, directory):
        (directory / "manifest.json").write_text(
            json.dumps(asdict(self.session), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def stop_recording(self):
        if self.session is None:
            return None
        directory = self.sessions_directory / self.session.session_id
        if self.session.camera_requested:
            if hasattr(self.camera, "send_request"):
                response = self.camera.send_request("record_stop", timeout_s=3.0)
                if response and response.get("event") == "command_ok":
                    self.session.video_file = response.get("result")
                else:
                    self.session.errors.append("camera stop response unavailable")
            elif not self.camera.send("record_stop"):
                self.session.errors.append("camera stop command queue unavailable")
        self.recording_sink.set_sink(None)
        if self.audio_writer is not None:
            self.audio_writer.close()
        self.session.stopped_monotonic_ns = self.clock_ns()
        completed = self.session
        self._write_manifest(directory)
        if self.muxer is not None and completed.video_file and completed.audio_file:
            self.muxer.submit(completed.video_file, completed.audio_file, directory / "combined.mp4")
        self.session = None
        self.audio_writer = None
        self.audio_channel = None
        return completed

    def close(self):
        self.stop_recording()
        self.audio_stop_event.set()
        if self.audio_thread is not None:
            self.audio_thread.join(timeout=2.0)
        try:
            self.microphone.close()
        except Exception:
            pass
        for optional_service in (self.broadcaster, self.speaker):
            if optional_service is not None:
                try:
                    optional_service.close()
                except Exception:
                    pass
        if self.muxer is not None:
            try:
                self.muxer.close()
            except Exception:
                pass
        try:
            self.camera.stop()
        except Exception:
            pass
