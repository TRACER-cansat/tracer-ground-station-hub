import socket
import struct
import threading
from dataclasses import dataclass

from tracer_runtime.audio_capture import AudioFrame, FRAME_BYTES
from tracer_runtime.bounded_channel import LatestQueue


MAGIC = b"TRAU"
VERSION = 1
HEADER = struct.Struct("!4sBQQH")


@dataclass(frozen=True)
class AudioPacket:
    sequence: int
    monotonic_ns: int
    pcm: bytes

    def encode(self):
        if len(self.pcm) != FRAME_BYTES:
            raise ValueError(f"invalid audio payload: {len(self.pcm)}")
        return HEADER.pack(MAGIC, VERSION, self.sequence, self.monotonic_ns, len(self.pcm)) + self.pcm

    @classmethod
    def decode(cls, data):
        if len(data) < HEADER.size:
            raise ValueError("audio packet is shorter than header")
        magic, version, sequence, monotonic_ns, payload_size = HEADER.unpack_from(data)
        if magic != MAGIC or version != VERSION:
            raise ValueError("invalid audio packet identity")
        payload = data[HEADER.size:]
        if len(payload) != payload_size or payload_size != FRAME_BYTES:
            raise ValueError("invalid audio packet payload size")
        return cls(sequence, monotonic_ns, payload)


class UdpAudioTransport:
    def __init__(self, bind_address=None):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if bind_address is not None:
            self.socket.bind(bind_address)

    def send(self, client, payload):
        self.socket.sendto(payload, client)

    def receive(self, timeout_s=0.1):
        self.socket.settimeout(timeout_s)
        return self.socket.recvfrom(2048)

    def close(self):
        self.socket.close()


class RealtimeAudioBroadcaster:
    """Latest-first audio sender; backlog is dropped instead of increasing latency."""

    def __init__(self, transport, max_buffered_frames=25):
        self.transport = transport
        self.frames = LatestQueue(max_buffered_frames)
        self.clients = set()
        self.clients_lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.frames_sent = 0
        self.send_errors = 0

    @property
    def dropped(self):
        return self.frames.dropped

    def add_client(self, host, port):
        with self.clients_lock:
            self.clients.add((host, int(port)))

    def remove_client(self, host, port):
        with self.clients_lock:
            self.clients.discard((host, int(port)))

    def publish(self, frame: AudioFrame):
        self.frames.publish(frame)

    def start(self):
        self.thread = threading.Thread(target=self._run, name="realtime-audio-sender", daemon=True)
        self.thread.start()

    def _run(self):
        while not self.stop_event.is_set() or self.frames.qsize():
            try:
                frame = self.frames.get(timeout=0.1)
            except Exception:
                continue
            try:
                payload = AudioPacket(frame.sequence, frame.monotonic_ns, frame.pcm).encode()
                with self.clients_lock:
                    clients = tuple(self.clients)
                for client in clients:
                    try:
                        self.transport.send(client, payload)
                    except Exception:
                        self.send_errors += 1
                self.frames_sent += 1
            finally:
                self.frames.task_done()

    def close(self):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=2.0)
        self.transport.close()


class AudioJitterBuffer:
    def __init__(self, max_wait_frames=3):
        self.max_wait_frames = max_wait_frames
        self.pending = {}
        self.expected_sequence = None
        self.lost_packets = 0
        self.duplicate_packets = 0

    def push(self, packet: AudioPacket):
        if self.expected_sequence is not None and packet.sequence < self.expected_sequence:
            self.duplicate_packets += 1
            return
        if packet.sequence in self.pending:
            self.duplicate_packets += 1
            return
        self.pending[packet.sequence] = packet
        if self.expected_sequence is None:
            self.expected_sequence = packet.sequence

    def pop(self):
        if self.expected_sequence is None:
            return None
        packet = self.pending.pop(self.expected_sequence, None)
        if packet is not None:
            self.expected_sequence += 1
            return packet.pcm
        if len(self.pending) >= self.max_wait_frames:
            self.expected_sequence += 1
            self.lost_packets += 1
            return bytes(FRAME_BYTES)
        return None

