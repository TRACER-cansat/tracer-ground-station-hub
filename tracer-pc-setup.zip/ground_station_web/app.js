const $ = id => document.getElementById(id);
// randomUUID is unavailable on plain HTTP LAN pages in several browsers.
const client = Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, '0')).join('');
let token = '', held = null, live = false, sources = [], levels = [], lastGood = 0, inflight = false, sequence = 0, restarting = false, motionInFlight = false;
let motionStarted = false;
let stationInstance = '', restartInstance = '', sourceLoading = false, sourceAttempt = 0, cameraReconnecting = false, hubPhase = 'offline';
let cameraRetryTimer = null, cameraRetryCount = 0;
let voiceRunning = false, voiceAvailable = false, voiceBusy = false, voiceDetail = '通話停止中', piVoiceReady = false, piVoiceDetail = '';
const text = (id, value) => $(id).textContent = value;
const n = value => { const result = Number(value); return Number.isFinite(result) ? result : null; };
const fmt = (value, digits = 2) => n(value) === null ? '—' : n(value).toFixed(digits);

async function command(key, timeout = 450) {
  if (!token) return false;
  try {
    const response = await fetch('/api/command', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Station-Token': token}, body: JSON.stringify({client, key, sequence: ++sequence}), signal: AbortSignal.timeout(timeout)});
    if (!response.ok) { text('key', '指令拒否 / 他の画面が操作中、または通信異常'); return false; }
    return true;
  } catch { return false; }
}
async function refreshMotion() {
  if (!held || !live || motionInFlight) return;
  const key = held, action = motionStarted ? 'heartbeat' : key;
  motionInFlight = true;
  try {
    const accepted = await command(action);
    if (held === key) {
      motionStarted = accepted;
      if (accepted) text('key', '入力：' + key.toUpperCase());
    }
  }
  finally { motionInFlight = false; }
}
async function stop() {
  held = null; motionStarted = false;
  document.querySelectorAll('.active').forEach(button => button.classList.remove('active'));
  text('key', '停止指令を送信中');
  let accepted = await command('stop', 1500);
  if (!accepted && held === null) accepted = await command('stop', 1500);
  if (held === null) text('key', accepted ? '停止確認' : '停止未確認・接続状態を確認');
}
function connectCamera() {
  if (cameraRetryTimer) clearTimeout(cameraRetryTimer);
  cameraRetryTimer = null;
  text('cameraNote', cameraRetryCount ? 'カメラ映像を再接続中' : 'カメラ映像を読み込み中');
  $('camera').src = '/video_feed?t=' + Date.now();
}
function disconnectCamera() {
  if (cameraRetryTimer) clearTimeout(cameraRetryTimer);
  cameraRetryTimer = null;
  $('camera').removeAttribute('src');
}
function press(key) { if (!live || voiceRunning || !$('arm').checked || held === key) return; held = key; motionStarted = false; document.querySelectorAll('.active').forEach(button => button.classList.remove('active')); text('key', '入力：' + key.toUpperCase()); document.querySelectorAll(`[data-key="${key}"]`).forEach(button => button.classList.add('active')); refreshMotion(); }

document.addEventListener('keydown', event => {
  if ((['SELECT', 'TEXTAREA'].includes(event.target.tagName) || (event.target.tagName === 'INPUT' && event.target.type !== 'checkbox')) && event.code !== 'Space') return;
  const key = event.key.toLowerCase();
  if (event.code === 'Space') { event.preventDefault(); if (!event.repeat) { $('arm').checked = false; stop(); } }
  else if (key === 'v' && !event.repeat) { event.preventDefault(); toggleVoice(); }
  else if ('wasd'.includes(key) && key.length === 1) { event.preventDefault(); press(key); }
  else if (key === 'e' && !event.repeat && live && $('arm').checked) command(key);
});
document.addEventListener('keyup', event => { if (event.key.toLowerCase() === held) stop(); });
window.addEventListener('blur', stop);
document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
$('arm').onchange = () => { if (!$('arm').checked) stop(); };
$('stop').onclick = () => { $('arm').checked = false; stop(); };
$('connectRover').onclick = async () => { text('banner', 'SSHでローバーのコードを起動中'); await hubAction('start'); };
$('endRover').onclick = async () => { stop(); $('arm').checked = false; text('banner', 'ローバーのコードを終了中'); await hubAction('stop'); };
$('restart').onclick = async () => { if (!live || restarting) return; stop(); $('arm').checked = false; restartInstance = stationInstance; if (await command('restart')) { restarting = true; live = false; $('restart').disabled = true; text('connection', 'コード再起動中'); text('banner', 'コードを再起動中・画面はそのまま表示します'); } };
async function hubAction(action) { if (!token) return; try { const response = await fetch('/api/hub-action', {method:'POST', headers:{'Content-Type':'application/json','X-Station-Token':token}, body:JSON.stringify({action})}); if (!response.ok) text('banner', '要求を受け付けられませんでした。接続状態を確認してください。'); } catch { text('banner', 'PCの地上局に接続できません'); } }
function showVoice() {
  $('voiceToggle').textContent = voiceRunning ? '音声相互通信モード終了 / V' : '音声相互通信モード開始 / V';
  $('voiceToggle').setAttribute('aria-pressed', String(voiceRunning));
  $('voiceToggle').disabled = voiceBusy || !voiceAvailable || (!voiceRunning && hubPhase !== 'connected');
  const playbackError = piVoiceDetail.startsWith('playback error');
  text('voiceStatus', !voiceAvailable ? '通話操作はHub PCのみ' : voiceRunning ? (piVoiceReady ? '双方向通話中' : '接続中 · ' + voiceDetail) : playbackError ? 'Pi音声出力エラー' : voiceDetail);
  $('voiceStatus').title = playbackError ? piVoiceDetail : voiceDetail;
}
async function refreshVoice() {
  try {
    const response = await fetch('/api/voice', {signal: AbortSignal.timeout(1200)});
    if (!response.ok) throw Error('音声状態を確認できません');
    const state = await response.json();
    voiceRunning = state.running; voiceAvailable = state.available; voiceDetail = state.detail;
    showVoice();
  } catch { voiceAvailable = false; showVoice(); }
}
async function toggleVoice() {
  if (!token || voiceBusy || !voiceAvailable || (!voiceRunning && hubPhase !== 'connected')) return;
  if (!voiceRunning) { $('arm').checked = false; await stop(); }
  voiceBusy = true; showVoice();
  try {
    if (location.protocol === 'https:' && !voiceRunning) {
      await browserVoice.start(token, () => {
        voiceRunning = false; voiceDetail = '通話が終了しました'; showVoice();
      });
      voiceRunning = true; voiceDetail = 'ブラウザで双方向通話中';
      return;
    }
    if (location.protocol === 'https:' && voiceRunning) await browserVoice.stop();
    const response = await fetch('/api/voice', {method:'POST', headers:{'Content-Type':'application/json','X-Station-Token':token}, body:JSON.stringify({action: voiceRunning ? 'stop' : 'start'}), signal: AbortSignal.timeout(4000)});
    const state = await response.json();
    voiceRunning = state.running; voiceDetail = state.detail || state.error || '音声操作に失敗しました';
  } catch (error) { voiceDetail = error.message || '音声処理に接続できません'; voiceRunning = false; }
  finally { voiceBusy = false; showVoice(); }
}
$('voiceToggle').onclick = toggleVoice;
document.querySelectorAll('[data-key]').forEach(button => {
  const key = button.dataset.key;
  if (key.length === 1 && 'wasd'.includes(key)) {
    button.onpointerdown = event => { button.setPointerCapture(event.pointerId); press(key); };
    button.onpointerup = button.onpointercancel = button.onlostpointercapture = () => { if (held === key) stop(); };
  } else button.onclick = () => { if (live && $('arm').checked) command(key); };
});
setInterval(() => {
  if (held && live) refreshMotion();
  if (Date.now() - lastGood > 1000 && live) { live = false; $('arm').checked = false; stop(); text('connection', '通信途絶'); text('banner', 'データ未更新・操作無効'); }
}, 180);

function plot(id, values, min, max) {
  const canvas = $(id), ctx = canvas.getContext('2d'), {width, height} = canvas;
  ctx.clearRect(0, 0, width, height); ctx.strokeStyle = '#21384b';
  for (let line = 1; line < 4; line++) { ctx.beginPath(); ctx.moveTo(0, height * line / 4); ctx.lineTo(width, height * line / 4); ctx.stroke(); }
  ctx.strokeStyle = '#66dfcb'; ctx.lineWidth = 2; ctx.beginPath();
  values.forEach((value, index) => { const px = index * width / Math.max(1, values.length - 1), py = height - (value - min) / (max - min) * height; index ? ctx.lineTo(px, py) : ctx.moveTo(px, py); });
  ctx.stroke();
}
function drawAttitude(roll, pitch, yaw) {
  const canvas = $('attitude'), ctx = canvas.getContext('2d'), {width, height} = canvas, cx = width / 2, cy = 48, radius = 42, valid = [roll, pitch, yaw].every(Number.isFinite);
  ctx.clearRect(0, 0, width, height); ctx.fillStyle = '#08121d'; ctx.fillRect(0, 0, width, height);
  if (!valid) { ctx.fillStyle = '#8396a8'; ctx.font = '14px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText('姿勢データ未受信', cx, 70); return; }
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.clip(); ctx.translate(cx, cy + pitch * 1.25); ctx.rotate(-roll * Math.PI / 180);
  ctx.fillStyle = '#176482'; ctx.fillRect(-150, -150, 300, 150); ctx.fillStyle = '#7d4e32'; ctx.fillRect(-150, 0, 300, 150); ctx.strokeStyle = '#dce7ee'; ctx.lineWidth = 1.2;
  for (let mark = -30; mark <= 30; mark += 5) { if (!mark) continue; const y = -mark * 2.5; ctx.beginPath(); ctx.moveTo(-17, y); ctx.lineTo(17, y); ctx.stroke(); if (mark % 10 === 0) { ctx.font = '9px Segoe UI'; ctx.fillStyle = '#dce7ee'; ctx.textAlign = 'right'; ctx.fillText(String(Math.abs(mark)), -21, y + 3); ctx.textAlign = 'left'; ctx.fillText(String(Math.abs(mark)), 21, y + 3); } }
  ctx.restore(); ctx.strokeStyle = '#dce7ee'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.stroke();
  ctx.save(); ctx.translate(cx, cy); ctx.strokeStyle = '#a8c2d4'; ctx.lineWidth = 1;
  for (let mark = -60; mark <= 60; mark += 10) { const angle = (mark - 90) * Math.PI / 180, inner = mark % 30 === 0 ? radius - 8 : radius - 4; ctx.beginPath(); ctx.moveTo(Math.cos(angle) * radius, Math.sin(angle) * radius); ctx.lineTo(Math.cos(angle) * inner, Math.sin(angle) * inner); ctx.stroke(); }
  ctx.restore(); ctx.fillStyle = '#f0cf77'; ctx.beginPath(); ctx.moveTo(cx, cy - 50); ctx.lineTo(cx - 4, cy - 43); ctx.lineTo(cx + 4, cy - 43); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#f0cf77'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx - 27, cy); ctx.lineTo(cx - 7, cy); ctx.lineTo(cx, cy + 5); ctx.lineTo(cx + 7, cy); ctx.lineTo(cx + 27, cy); ctx.stroke();
  const compassY = 103, compassWidth = 190;
  ctx.save(); ctx.beginPath(); ctx.rect(cx - compassWidth / 2, compassY - 13, compassWidth, 25); ctx.clip(); ctx.translate(cx, compassY); ctx.strokeStyle = '#456276'; ctx.fillStyle = '#dce7ee'; ctx.lineWidth = 1;
  for (let degree = Math.floor(yaw / 10) * 10 - 110; degree <= yaw + 110; degree += 10) { const px = (degree - yaw) * 1.7; ctx.beginPath(); ctx.moveTo(px, -12); ctx.lineTo(px, degree % 30 === 0 ? -3 : -7); ctx.stroke(); if (degree % 30 === 0) { let label = ((degree % 360) + 360) % 360; label = ({0: 'N', 90: 'E', 180: 'S', 270: 'W'})[label] || label; ctx.font = '10px Segoe UI'; ctx.textAlign = 'center'; ctx.fillText(label, px, 10); } }
  ctx.restore(); ctx.fillStyle = '#f0cf77'; ctx.beginPath(); ctx.moveTo(cx, compassY - 13); ctx.lineTo(cx - 4, compassY - 18); ctx.lineTo(cx + 4, compassY - 18); ctx.closePath(); ctx.fill(); ctx.font = '11px Segoe UI'; ctx.textAlign = 'center'; ctx.fillStyle = '#dce7ee'; ctx.fillText(String(Math.round((yaw + 360) % 360)).padStart(3, '0') + '°', cx, compassY - 23);
}

async function refresh() {
  if (inflight) return;
  inflight = true;
  try {
    const response = await fetch('/api/state', {signal: AbortSignal.timeout(700)}), state = await response.json();
    if (!response.ok || state.error) throw Error(state.error || '状態を受信できません');
    if (restarting && state.instance_id === restartInstance) { text('connection', 'コード再起動中'); text('banner', 'コードを再起動中・ローバーの再起動を待っています'); return; }
    lastGood = Date.now(); live = true;
    piVoiceReady = state.statuses?.voice?.state === 'ready'; piVoiceDetail = state.statuses?.voice?.detail || '';
    if (state.voice_mode) { $('arm').checked = false; text('key', '音声相互通信モード・走行停止'); }
    showVoice();
    stationInstance = state.instance_id || '';
    if (restarting) { restarting = false; $('restart').disabled = false; sources = []; loadSources(); }
    if (!sources.length) loadSources();
    text('connection', state.demo ? 'DEMO / 模擬接続' : 'LIVE / 直接通信'); text('banner', state.demo ? 'デモモード：すべて模擬データ・実機は動きません' : '実機モード：操作有効化で制御可能'); text('time', '稼働 ' + state.uptime_s + ' 秒');
    $('statuses').replaceChildren();
    for (const [name, status] of Object.entries(state.statuses || {})) { const row = document.createElement('div'), label = document.createElement('span'), value = document.createElement('b'); row.className = 'status'; label.textContent = name; value.textContent = status.state; value.className = status.state; row.title = status.detail; row.append(label, value); $('statuses').append(row); }
    const voltage = state.battery?.battery_voltage_v; text('voltage', fmt(voltage) + ' V'); $('battery').value = n(voltage) === null ? 0 : Math.max(0, Math.min(100, (voltage - 6.6) / 1.8 * 100)); text('batteryText', n(voltage) === null ? '—%' : Math.round($('battery').value) + '%'); $('batteryText').title = n(voltage) === null ? '未受信' : voltage <= 6.6 ? '重大警告 / 停止推奨' : voltage <= 7 ? '低電圧警告' : '電圧からの推定残量'; $('batteryText').style.color = n(voltage) !== null && voltage <= 7 ? '#e48e94' : '';
    const gnss = state.gnss; text('gnss', gnss ? `緯度 ${fmt(gnss.latitude_deg, 7)}\n経度 ${fmt(gnss.longitude_deg, 7)}\n衛星 ${gnss.satellites} / 高度 ${fmt(gnss.altitude_m)} m\n速度 ${fmt(gnss.speed_knots)} knot / 方位 ${fmt(gnss.course_deg)}°` : '未測位 / 有効なfixなし');
    const distance = state.ultrasonic; text('distance', distance ? `S1：${fmt(distance.S1_Distance_cm)} cm   S2：${fmt(distance.S2_Distance_cm)} cm` : '未受信'); plot('range', distance ? [n(distance.S1_Distance_cm) || 0, n(distance.S2_Distance_cm) || 0] : [], 0, 300);
    const imu = state.imu, roll = n(imu?.roll), pitch = n(imu?.pitch), yaw = n(imu?.heading); drawAttitude(roll, pitch, yaw); text('rollValue', fmt(roll, 1) + '°'); text('pitchValue', fmt(pitch, 1) + '°'); text('yawValue', fmt(yaw, 1) + '°'); $('attitude').setAttribute('aria-label', imu ? `航空計器：ロール ${fmt(roll, 1)}度、ピッチ ${fmt(pitch, 1)}度、ヨー ${fmt(yaw, 1)}度` : '姿勢データ未受信');
    text('db', state.audio ? fmt(state.audio.dbfs, 1) + ' dBFS' : '— dBFS'); levels.push(state.audio?.dbfs ?? -96); if (levels.length > 180) levels.shift(); plot('audio', levels, -96, 0); plot('wave', state.audio?.wave || [], -1, 1); text('commands', (state.events || []).slice(-5).map(event => `${event.time} ${event.key} → ${event.result}`).join('\n')); text('recording', state.recording ? '録画中' : '');
    const cameraStatus = state.statuses?.camera;
    if (state.demo) { disconnectCamera(); text('cameraNote', 'DEMO / 実機映像は接続後に表示'); }
    else if (cameraStatus?.state !== 'ready') { cameraReconnecting = true; disconnectCamera(); text('cameraNote', 'カメラ再接続中：' + (cameraStatus?.detail || '初期化待ち')); text('banner', 'カメラ再接続中・操作状態を確認してください'); }
    else if (!$('camera').getAttribute('src') || cameraReconnecting) { cameraReconnecting = false; connectCamera(); }
  } catch (error) { if (restarting) { text('connection', 'コード再起動中'); text('banner', 'コードを再起動中・接続復帰を待っています'); } else if (hubPhase === 'connected') { text('banner', '受信エラー / ' + error.message); } }
  finally { inflight = false; }
}

$('camera').onload = () => { cameraRetryCount = 0; text('cameraNote', '映像接続中'); };
$('camera').onerror = () => {
  if (!live || cameraRetryTimer) return;
  cameraRetryCount++;
  text('cameraNote', `カメラ再接続中（${cameraRetryCount}回目）`);
  cameraRetryTimer = setTimeout(() => {
    cameraRetryTimer = null;
    if (live && hubPhase === 'connected') connectCamera();
  }, Math.min(5000, 1000 * cameraRetryCount));
};
$('retry').onclick = () => { cameraRetryCount = 0; connectCamera(); };
function showSource() { const source = sources[$('sourceSelect').selectedIndex]; if (source) { text('source', source.source); text('hash', 'SHA256 ' + source.sha256); } }
async function loadSources() { if (sourceLoading || Date.now() - sourceAttempt < 2000) return; sourceLoading = true; sourceAttempt = Date.now(); try { const next = await (await fetch('/api/source')).json(); if (Array.isArray(next) && next.length) { sources = next; $('sourceSelect').replaceChildren(); sources.forEach(source => { const option = document.createElement('option'); option.textContent = source.name; $('sourceSelect').append(option); }); showSource(); } } catch {} finally { sourceLoading = false; } }
$('sourceSelect').onchange = showSource;
$('inspect').onclick = () => { stop(); $('arm').checked = false; $('inspector').showModal(); };
(async () => { token = (await (await fetch('/api/session')).json()).token; loadSources(); refresh(); })().catch(() => text('banner', '初期接続失敗・ページを再読込してください'));
async function refreshHubStatus() { try { const status = await (await fetch('/api/hub-status', {signal: AbortSignal.timeout(1200)})).json(); hubPhase = status.phase; if (restarting && hubPhase === 'reconnecting') restarting = false; const busy = ['starting','connecting','connected','restarting','stopping'].includes(hubPhase); $('connectRover').disabled = busy; $('endRover').disabled = !['connected','connecting','reconnecting','restarting'].includes(hubPhase); $('restart').disabled = !live || restarting; if (hubPhase !== 'connected') { piVoiceReady = false; piVoiceDetail = ''; if (live) { live = false; $('arm').checked = false; stop(); } text('connection', ({offline:'未接続',starting:'起動中',connecting:'接続中',reconnecting:'再接続中',restarting:'コード再起動中',stopping:'終了中'})[hubPhase] || hubPhase); text('banner', restarting ? 'コードを再起動中・接続復帰を待っています' : status.detail); text('cameraNote', hubPhase === 'offline' ? 'ローバー未接続' : 'カメラ接続待ち'); if (hubPhase === 'offline') { $('camera').removeAttribute('src'); $('statuses').replaceChildren(); text('voltage', '— V'); text('batteryText', '—%'); text('gnss', '未接続'); text('distance', '未接続'); text('db', '— dBFS'); } } showVoice(); } catch { text('connection', 'PC側の接続状態を確認中'); } }
refreshHubStatus(); setInterval(refreshHubStatus, 500);
refreshVoice(); setInterval(refreshVoice, 700);
setInterval(refresh, 200);
setInterval(async () => { try { text('log', (await (await fetch('/api/log', {signal: AbortSignal.timeout(900)})).json()).log); } catch {} }, 1000);
