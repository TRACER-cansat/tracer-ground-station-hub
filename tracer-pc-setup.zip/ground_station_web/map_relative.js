// GNSS-free reference view. Distance is inferred from commanded travel time,
// a user-set nominal speed, and BNO055 heading; it is not measured odometry.
let relativePosition = [0, 0], relativeAt = null, relativeSample = null;
function relativeTick(state) {
  if (origin !== null) {
    origin = null; track = []; obstacles = []; last = null; lastFix = null;
    relativePosition = [0, 0]; relativeAt = null; relativeSample = null;
  }
  const now = performance.now() / 1000;
  const heading = number(state.imu?.heading);
  const imuReady = state.demo || state.imu?.bno_status === 'Ready';
  if (!track.length) track.push([0, 0]);
  const speed = Math.max(0, number($('estimatedSpeed').value) || 0);
  const dt = relativeAt === null ? 0 : Math.min(.5, Math.max(0, now - relativeAt));
  relativeAt = now;
  if (imuReady && heading !== null && state.moving && ['w', 's'].includes(state.drive_key) && speed > 0) {
    const direction = state.drive_key === 'w' ? 1 : -1;
    const angle = heading * Math.PI / 180;
    relativePosition = [relativePosition[0] + direction * Math.sin(angle) * speed * dt,
                        relativePosition[1] + direction * Math.cos(angle) * speed * dt];
    if (Math.hypot(relativePosition[0]-track.at(-1)[0], relativePosition[1]-track.at(-1)[1]) > .03) {
      track.push([...relativePosition]);
      if (track.length > 2000) track.shift();
    }
  }
  const signature = [state.imu?.timestamp, state.ultrasonic?.S1_Timestamp,
                     state.ultrasonic?.S2_Timestamp, track.length].join(':');
  if (imuReady && heading !== null && signature !== relativeSample) {
    relativeSample = signature;
    for (let i = 1; i <= 2; i++) {
      const d = number(state.ultrasonic?.[`S${i}_Distance_cm`]);
      const mount = number($(`angle${i}`).value);
      if (d === null || d <= 2 || d >= 400 || mount === null) continue;
      const angle = (heading + mount) * Math.PI / 180;
      obstacles.push([relativePosition[0] + Math.sin(angle) * d / 100,
                      relativePosition[1] + Math.cos(angle) * d / 100]);
    }
    if (obstacles.length > 4000) obstacles.splice(0, obstacles.length - 4000);
  }
  $('banner').textContent = 'LIVE / GNSS未測位・相対プロット（概算）';
  $('position').textContent = !imuReady || heading === null ? 'GNSS未測位 / IMU方位待ち' :
    `GNSS未測位 / 方位 ${heading.toFixed(1)}° / 設定速度 ${speed.toFixed(2)} m/s。軌跡は実測位置ではありません`;
  draw();
}
