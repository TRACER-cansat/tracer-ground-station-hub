// Browser PCM endpoint for HTTPS visitors. The local HTTP PC endpoint remains available.
window.browserVoice = (() => {
  let socket = null, context = null, media = null, source = null, capture = null, playback = null;
  let pending = [], capturePhase = 0, output = [], outputFrame = null;
  let outputIndex = 0, outputPhase = 0, outputSample = 0, generation = 0;

  async function stop() {
    generation++;
    if (socket) { socket.onclose = null; socket.close(); socket = null; }
    for (const node of [source, capture, playback]) if (node) node.disconnect();
    source = capture = playback = null;
    if (media) { media.getTracks().forEach(track => track.stop()); media = null; }
    if (context) { await context.close().catch(() => {}); context = null; }
    pending = []; output = []; outputFrame = null;
    outputIndex = outputPhase = outputSample = capturePhase = 0;
  }

  function nextSample() {
    if (!outputFrame || outputIndex >= outputFrame.length) {
      outputFrame = output.shift() || null;
      outputIndex = 0;
    }
    return outputFrame ? outputFrame[outputIndex++] / 32768 : 0;
  }

  async function start(token, ended) {
    if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      throw Error('マイクはHTTPSの画面で使用してください');
    }
    await stop();
    const current = generation;
    try {
      media = await navigator.mediaDevices.getUserMedia({audio: {channelCount: 1,
        echoCancellation: true, noiseSuppression: true, autoGainControl: true}});
      context = new AudioContext({latencyHint: 'interactive'});
      await context.resume();
      const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
      socket = new WebSocket(`${scheme}//${location.host}/api/voice-stream?token=${encodeURIComponent(token)}`);
      socket.binaryType = 'arraybuffer';
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(Error('通話接続がタイムアウトしました')), 6000);
        socket.onopen = () => { clearTimeout(timer); resolve(); };
        socket.onerror = () => { clearTimeout(timer); reject(Error('ローバーの通話に接続できません')); };
      });
      if (current !== generation) throw Error('通話が中止されました');
      socket.onmessage = event => {
        if (!(event.data instanceof ArrayBuffer) || event.data.byteLength !== 320) return;
        if (output.length >= 8) output.shift();
        output.push(new Int16Array(event.data));
      };
      socket.onclose = () => { if (current === generation) { stop(); ended?.(); } };
      source = context.createMediaStreamSource(media);
      capture = context.createScriptProcessor(1024, 1, 1);
      capture.onaudioprocess = event => {
        event.outputBuffer.getChannelData(0).fill(0);
        const input = event.inputBuffer.getChannelData(0);
        for (let i = 0; i < input.length; i++) {
          capturePhase += 8000 / context.sampleRate;
          if (capturePhase < 1) continue;
          capturePhase -= 1;
          pending.push(Math.max(-32768, Math.min(32767, Math.round(input[i] * 32767))));
          if (pending.length === 160) {
            if (socket?.readyState === WebSocket.OPEN && socket.bufferedAmount < 2560) {
              socket.send(Int16Array.from(pending).buffer);
            }
            pending = [];
          }
        }
      };
      source.connect(capture); capture.connect(context.destination);
      playback = context.createScriptProcessor(1024, 1, 1);
      playback.onaudioprocess = event => {
        const samples = event.outputBuffer.getChannelData(0);
        for (let i = 0; i < samples.length; i++) {
          outputPhase += 8000 / context.sampleRate;
          if (outputPhase >= 1) { outputPhase -= 1; outputSample = nextSample(); }
          samples[i] = outputSample;
        }
      };
      playback.connect(context.destination);
    } catch (error) { await stop(); throw error; }
  }
  return {start, stop};
})();
