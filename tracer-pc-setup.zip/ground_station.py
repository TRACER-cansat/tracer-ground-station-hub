#!/usr/bin/env python3
"""Rover ground station. The PC Hub can reach it directly on the local Wi-Fi."""
import argparse
import array
import csv
import hashlib
import json
import math
import os
import secrets
import signal
import sys
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent


def loopback_camera_worker(*args):
    # Restrict the existing camera's HTTP listener for this launch only.
    import streaming_back_record_v3_rover as camera_module
    from tracer_runtime.camera_process import camera_v3_worker
    camera_module.HOST = '127.0.0.1'
    camera_v3_worker(*args)


class AudioMeter:
    def __init__(self):
        self.value = None

    def publish(self, frame):
        samples = array.array('h', frame.pcm)
        import sys
        if sys.byteorder != 'little':
            samples.byteswap()
        if not samples:
            return
        rms = math.sqrt(sum(x*x for x in samples)/len(samples))/32768
        self.value = {'dbfs': max(-96, 20*math.log10(max(rms, 1e-6))),
                      'peak': max(abs(x) for x in samples)/32768,
                      'wave': [x/32768 for x in samples[::4]], 'at': time.monotonic()}


class CsvTail:
    """Incremental bounded reads; incomplete CSV rows wait for the next tick."""
    def __init__(self, path, timestamp_keys=()):
        self.path, self.offset, self.pending, self.header = Path(path), 0, '', None
        self.row, self.at = None, 0
        self.timestamp_keys = timestamp_keys

    def read(self):
        try:
            if self.path.stat().st_size < self.offset:
                self.offset, self.pending, self.header = 0, '', None
            with self.path.open('rb') as stream:
                stream.seek(self.offset)
                chunk = stream.read(65536)
                self.offset = stream.tell()
            parts = (self.pending + chunk.decode('utf-8', errors='replace')).split('\n')
            self.pending = parts.pop()
            for line in parts:
                cells = next(csv.reader([line]))
                if self.header is None:
                    self.header = cells
                elif len(cells) == len(self.header):
                    self.row, self.at = dict(zip(self.header, cells)), time.monotonic()
        except OSError:
            pass
        if time.monotonic()-self.at >= 3:
            return None
        if self.row and self.timestamp_keys:
            fresh = False
            for key in self.timestamp_keys:
                try:
                    age = time.time()-float(self.row[key])
                    fresh |= 0 <= age < 3
                except (ValueError, KeyError):
                    pass
            if not fresh:
                return None
        return self.row


class Station:
    def __init__(self, demo=False):
        self.demo = demo
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.token = secrets.token_urlsafe(32)
        self.instance_id = secrets.token_hex(8)
        self.owner = None
        self.sequences = {}
        self.lease = 0
        self.motion = False
        self.drive_key = None
        self.voice_mode = False
        self.state = {}
        self.audio = AudioMeter()
        self.imu = CsvTail(ROOT/'bno055_data.csv', ('timestamp',))
        self.distance = CsvTail(ROOT/'distance_log.csv', ('S1_Timestamp','S2_Timestamp'))
        self.sources = []
        for name in ('rover.py','drive.py','ground_station.py',
                     'rover_system.py',
                     'rover_drive_sensors.py'):
            content=(ROOT/name).read_bytes()
            self.sources.append({'name':name,'sha256':hashlib.sha256(content).hexdigest(),
                                 'source':content.decode('utf-8')})
        self.supervisor = self.writer = self.battery = None
        self.track = deque(maxlen=2000)
        self.events = deque(maxlen=80)
        self.started = time.monotonic()
        self.started_wall = time.time()
        self.control_ready = demo
        self.restarting = False
        self.restart_thread = None

    def start(self, args):
        if not self.demo:
            from rover_system import build_system
            from tracer_runtime.battery_monitor import BatteryMonitor
            self.supervisor, self.writer = build_system(args)
            self.supervisor.media.camera.worker_target = loopback_camera_worker
            self.supervisor.media.microphone.frame_sink.add(self.audio)
            self.voice_link = self.supervisor.voice_link
            if args.allow_network_clients:
                self.voice_link.host = '0.0.0.0'
            self.battery = BatteryMonitor()
            self.battery.start()
            # On the Pi, the camera encoder can take more than eight seconds
            # to warm up while the legacy Step 7 child is also starting.
            self.supervisor.start(timeout_s=20)
            self.voice_link.start()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()
        self.watchdog = threading.Thread(target=self.watch, daemon=True)
        self.watchdog.start()

    def watch(self):
        while not self.stop.wait(.05):
            with self.lock:
                if self.motion and time.monotonic()-self.lease > .6:
                    self.halt()
                    self.owner = None

    def command(self, client, key, sequence):
        with self.lock:
            now = time.monotonic()
            if sequence <= self.sequences.get(client, -1):
                return False
            if len(self.sequences) >= 100 and client not in self.sequences:
                return False
            self.sequences[client] = sequence
            if key == 'stop':
                self.halt()
                self.owner = None
                return True
            if key == 'restart':
                return self.restart()
            if key == 'voice_start':
                self.halt()
                self.owner = None
                self.voice_mode = True
                self.events.append({'key': key, 'time': time.strftime('%H:%M:%S'), 'result':'stopped for voice'})
                return True
            if key == 'voice_stop':
                self.halt()
                self.owner = None
                self.voice_mode = False
                return True
            if self.voice_mode and key in ('w', 'a', 's', 'd', 'heartbeat'):
                return False
            if self.owner not in (None, client) and now-self.lease < .8:
                return False
            self.owner, self.lease = client, now
            if key == 'heartbeat':
                return True
            routes = {'w': ('control','forward'), 'a': ('control','left'),
                      's': ('control','back'), 'd': ('control','right'),
                      'e': ('control','led'), 'record_start': ('media','record_start'),
                      'record_stop': ('media','record_stop')}
            if key not in routes:
                return False
            if key in ('w','a','s','d'):
                # Serialize short PTY writes with stop; no stale movement queue.
                if not self.control_ready or (self.supervisor and not self.supervisor.control.tick().operational):
                    return False
                if self.supervisor:
                    self.supervisor.control.command(routes[key][1])
                ok = True
            else:
                self.halt()
                ok = self.demo or self.supervisor.submit(*routes[key])
            if ok:
                self.motion = key in 'wasd' and len(key) == 1
                if self.motion:
                    self.drive_key = key
                self.events.append({'key': key, 'time': time.strftime('%H:%M:%S'), 'result':'queued'})
            return ok

    def halt(self):
        self.motion = False
        self.drive_key = None
        if self.supervisor:
            # Direct emergency path bypasses normal queued commands.
            self.supervisor.control.emergency_stop()

    def restart(self):
        """Restart this program and its managed children, never the Pi itself."""
        if self.restarting:
            return False
        self.restarting = True
        self.halt()
        self.restart_thread = threading.Thread(
            target=self._restart_process, name='ground-station-restart', daemon=True)
        self.restart_thread.start()
        return True

    def _restart_process(self):
        # Let the successful HTTP response leave the socket before teardown.
        time.sleep(.2)
        self.close()
        os.execv(sys.executable, [sys.executable, *sys.argv])

    def run(self):
        while not self.stop.is_set():
            now = time.monotonic()
            try:
                with self.lock:
                    if self.motion and now-self.lease > .6:
                        self.halt()
                        self.owner = None
                if self.demo:
                    t = now-self.started
                    state = {'statuses': {n:{'state':'demo','detail':'模擬データ'} for n in
                             ('control','gnss','camera','microphone','battery','imu','ultrasonic')},
                             'battery': {'battery_voltage_v':7.65},
                             'gnss': {'latitude_deg':35.73+math.sin(t/40)*.0001,
                                      'longitude_deg':140.06+math.cos(t/40)*.0001,'satellites':12},
                             'imu':{'heading':str(t*3%360),'roll':str(math.sin(t)*8),'pitch':str(math.cos(t)*5),
                                    'acceleration_x':'.1','acceleration_y':'.2','acceleration_z':'0'},
                             'ultrasonic':{'S1_Distance_cm':str(80+20*math.sin(t)), 'S2_Distance_cm':'120'},
                             'audio':{'dbfs':-35+10*math.sin(t),'peak':.2,'wave':[math.sin(i*.3+t)*.3 for i in range(80)]}}
                else:
                    statuses = self.supervisor.tick()
                    statuses.update(battery=self.battery.tick(), camera=self.supervisor.media.camera_status,
                                    microphone=self.supervisor.media.microphone_status)
                    from tracer_runtime.component_status import ComponentState, ComponentStatus
                    voice_state = (ComponentState.READY if self.voice_link.client_connected.is_set()
                                   else ComponentState.DEGRADED)
                    statuses['voice'] = ComponentStatus(
                        'voice', voice_state, self.voice_link.status,
                        data={'port': self.voice_link.port,
                              'connected': self.voice_link.client_connected.is_set(),
                              'errors': self.voice_link.errors})
                    state = {'statuses':{n:v.to_dict() for n,v in statuses.items()},
                             'battery':statuses['battery'].data,
                             'gnss':(statuses['gnss'].data or {}).get('fix'),
                             'imu': self.imu.read(), 'ultrasonic':self.distance.read(),
                             'audio':self.audio.value if self.audio.value and now-self.audio.value['at'] < 1 else None}
                    try:
                        # CSV starts after motor/keyboard initialization. Never queue
                        # movement into the PTY while the legacy script is booting.
                        if float((state['imu'] or {}).get('timestamp',0)) >= self.started_wall:
                            self.control_ready = True
                    except (ValueError,TypeError):
                        pass
                    if not self.control_ready:
                        state['statuses']['control']={'state':'unavailable','detail':'初期化待ち・移動指令は拒否'}
                    for name, value in [('imu',state['imu']),('ultrasonic',state['ultrasonic'])]:
                        state['statuses'][name]={'state':'ready' if value else 'unavailable','detail':'CSV受信' if value else 'データなし / 3秒以上未更新'}
                    if state['imu'] and state['imu'].get('bno_status') != 'Ready':
                        state['statuses']['imu']['state'] = 'degraded'
                    for i in (1,2):
                        value=(state['ultrasonic'] or {}).get(f'S{i}_Distance_cm')
                        try:
                            distance=float(value)
                            good=math.isfinite(distance) and distance>0
                        except (TypeError,ValueError):
                            good=False
                        state['statuses'][f'ultrasonic_{i}']={'state':'ready' if good else 'unavailable',
                            'detail':str(value) if value is not None else '未受信'}
                    camera=self.supervisor.media.camera.process
                    if camera is not None and not camera.is_alive():
                        detail = self.supervisor.media.camera_status.detail
                        state['statuses']['camera']={
                            'state':'unavailable',
                            'detail':f'カメラプロセス終了: {detail}',
                        }
                fix = state.get('gnss')
                if fix and all(math.isfinite(fix.get(k, float('nan'))) for k in ('latitude_deg','longitude_deg')):
                    point = [fix['latitude_deg'],fix['longitude_deg']]
                    if not self.track or point != self.track[-1]:
                        self.track.append(point)
                state.update(demo=self.demo, uptime_s=round(now-self.started),
                             instance_id=self.instance_id,
                             track=list(self.track), events=list(self.events), moving=self.motion,
                             voice_mode=self.voice_mode, drive_key=self.drive_key,
                             recording=bool(self.supervisor and self.supervisor.media.session))
                with self.lock:
                    self.state = state
            except Exception as error:
                with self.lock:
                    self.state = {'error':str(error),'demo':self.demo}
                    self.halt()
            self.stop.wait(.1)

    def close(self):
        self.stop.set()
        if hasattr(self,'thread'):
            self.thread.join(2)
        self.halt()
        if self.supervisor:
            if getattr(self, 'voice_link', None):
                self.voice_link.close()
            self.supervisor.close()
            self.battery.close()
            self.writer.close()


def handler(station, port, allow_network_clients=False):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, code, body, kind='application/json'):
            self.send_response(code)
            self.send_header('Content-Type',kind)
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if (not allow_network_clients and
                self.headers.get('Host') not in (f'localhost:{port}',f'127.0.0.1:{port}')):
                return self.send(403,b'{}')
            path = self.path.split('?')[0]
            if path == '/api/state':
                with station.lock:
                    return self.send(200,json.dumps(station.state,allow_nan=False).encode())
            if path == '/api/session':
                return self.send(200,json.dumps({'token':station.token}).encode())
            if path == '/api/source':
                return self.send(200,json.dumps(station.sources).encode())
            if path == '/api/log':
                try:
                    with (ROOT/'step11_control.log').open('rb') as f:
                        f.seek(max(0,f.seek(0,2)-16000))
                        log=f.read().decode(errors='replace')
                except OSError:
                    log='制御ログ未生成'
                return self.send(200,json.dumps({'log':log}).encode())
            if path == '/video_feed' and not station.demo:
                try:
                    with urlopen('http://127.0.0.1:5000/video_feed',timeout=2) as upstream:
                        self.send_response(200)
                        self.send_header('Content-Type',upstream.headers['Content-Type'])
                        self.send_header('Cache-Control','no-store')
                        self.end_headers()
                        while not station.stop.is_set():
                            chunk=upstream.read1(65536)
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            self.wfile.flush()
                except (OSError,TimeoutError):
                    pass
                return
            files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/map':'map.html','/map.js':'map.js',
                   '/map_relative.js':'map_relative.js','/voice_browser.js':'voice_browser.js'}
            if path in files:
                f=ROOT/'ground_station_web'/files[path]
                kind={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}[f.suffix]
                return self.send(200,f.read_bytes(),kind)
            self.send(404,b'{}')

        def do_POST(self):
            if (self.path != '/api/command' or self.headers.get('X-Station-Token') != station.token
                or (not allow_network_clients and self.headers.get('Origin') not in
                    (f'http://localhost:{port}',f'http://127.0.0.1:{port}'))):
                return self.send(403,b'{}')
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<1024:
                    raise ValueError('size')
                body=json.loads(self.rfile.read(size))
                client,key=body['client'],body['key']
                if not isinstance(client,str) or not 1<=len(client)<=100 or not isinstance(key,str):
                    raise ValueError('fields')
                sequence=body['sequence']
                if not isinstance(sequence,int) or isinstance(sequence,bool) or sequence<0:
                    raise ValueError('sequence')
                ok=station.command(client,key,sequence)
                self.send(200 if ok else 409,json.dumps({'accepted':ok}).encode())
            except (ValueError,KeyError,TypeError):
                self.send(400,b'{}')
    return Handler


def main():
    import os
    os.chdir(ROOT)
    p=argparse.ArgumentParser()
    p.add_argument('--demo',action='store_true')
    p.add_argument('--port',type=int,default=8765)
    p.add_argument('--microphone-device',default='analog',
                   help='analog (MCP3204 CH0), auto, or an ALSA device')
    p.add_argument('--microphone-adc-channel',type=int,default=0)
    p.add_argument('--microphone-gain',type=float,default=18.0)
    p.add_argument('--speaker-device',default='default')
    p.add_argument('--voice-speaker-device', default='gpio12-pwm',
                   help='gpio12-pwm for the Grove speaker, or an ALSA device name')
    p.add_argument('--sounds',default='sounds')
    p.add_argument('--audio-client',action='append',default=[])
    p.add_argument('--voice-port',type=int,default=50100)
    p.add_argument('--allow-network-clients',action='store_true',
                   help='accept requests forwarded through the PC Ground Station Hub')
    args=p.parse_args()
    station=Station(args.demo)
    bind_host = '0.0.0.0' if args.allow_network_clients else '127.0.0.1'
    server=ThreadingHTTPServer((bind_host,args.port),
                               handler(station,args.port,args.allow_network_clients))
    server.daemon_threads=True
    def shutdown(*_):
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGINT,shutdown)
    signal.signal(signal.SIGTERM,shutdown)
    try:
        station.start(args)
        print(f'Ground station: http://localhost:{args.port} / demo={args.demo}',flush=True)
        server.serve_forever()
    finally:
        station.close()
        server.server_close()

if __name__=='__main__':
    main()
