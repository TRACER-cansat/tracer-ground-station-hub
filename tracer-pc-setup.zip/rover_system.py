#!/usr/bin/env python3
"""Step 11 entry point: Step 7 control supervised beside GNSS and camera/audio."""

import argparse
import signal
import sys
import threading
import time

from integration_nightmotor2_step8_gnss_reconnect import GnssCsvWriter
from gnss_component_step2_positioning import DFRobotGnssProbe
from tracer_runtime.audio_capture import (AutoArecordBackend, AsyncWavWriter,
                                          Mcp3204MicrophoneBackend, MicrophoneCaptureService)
from tracer_runtime.battery_monitor import BatteryMonitor
from tracer_runtime.bounded_channel import LatestQueue
from tracer_runtime.camera_process import CameraProcessController
from tracer_runtime.fanout import FanoutSink, SwitchableSink, VadFrameSink
from tracer_runtime.gnss_reconnect import GnssReconnectService
from tracer_runtime.media_service import MediaService
from tracer_runtime.media_mux import AsyncMediaMuxer, mux_audio_video
from tracer_runtime.realtime_audio import RealtimeAudioBroadcaster, UdpAudioTransport
from tracer_runtime.speaker import AplayBackend, SpeakerCommandPlayer
from tracer_runtime.system_supervisor import LegacyStep7Process, SystemSupervisor
from tracer_runtime.voice_activity import VadService, VoiceActivityDetector
from tracer_runtime.voice_link import VoiceLinkServer


KEY_COMMANDS = {
    "w": ("control", "forward", None),
    "a": ("control", "left", None),
    "d": ("control", "right", None),
    "s": ("control", "back", None),
    "e": ("control", "led", None),
    " ": ("control", "emergency_stop", None),
}


class OperatorConsole:
    def __init__(self, stream=sys.stdin):
        self.stream = stream
        self.settings = None
        self.termios = None

    def start(self):
        if not self.stream.isatty():
            return False
        try:
            import termios
            import tty
            self.termios = termios
            self.settings = termios.tcgetattr(self.stream.fileno())
            tty.setcbreak(self.stream.fileno())
            return True
        except (ImportError, OSError):
            return False

    def poll(self):
        if self.settings is None:
            return None
        import select
        readable, _, _ = select.select([self.stream], [], [], 0)
        return self.stream.read(1).lower() if readable else None

    def close(self):
        if self.settings is not None:
            self.termios.tcsetattr(self.stream.fileno(), self.termios.TCSADRAIN, self.settings)
            self.settings = None


def parse_sound_map(values):
    result = {}
    for value in values:
        key, filename = value.split("=", 1)
        if len(key) != 1 or key in KEY_COMMANDS or key in ("q", "r", "x"):
            raise ValueError(f"invalid or reserved sound key: {key}")
        result[key] = filename
    return result


def route_operator_key(supervisor, key, recording, sound_map=None):
    if key == "q":
        return recording, False
    if key == "r":
        supervisor.submit("media", "record_stop" if recording else "record_start")
        return not recording, True
    if key == "x":
        supervisor.submit("speaker", "stop")
        return recording, True
    if sound_map and key in sound_map:
        supervisor.submit("speaker", "play", sound_map[key])
        return recording, True
    command = KEY_COMMANDS.get(key)
    if command is not None:
        supervisor.submit(*command)
    return recording, True


def build_system(args):
    gnss_samples = LatestQueue(256)
    gnss_writer = GnssCsvWriter(gnss_samples)
    gnss_writer.start()
    gnss = GnssReconnectService(DFRobotGnssProbe, gnss_samples)
    record_sink = SwitchableSink()
    voice_events = LatestQueue(64)
    speaker = SpeakerCommandPlayer(args.sounds, AplayBackend(args.speaker_device))
    voice_link = VoiceLinkServer(getattr(args, "voice_speaker_device", "gpio12-pwm"), port=args.voice_port)
    vad = VadService(VoiceActivityDetector(), voice_events)
    broadcaster = RealtimeAudioBroadcaster(UdpAudioTransport())
    for value in args.audio_client:
        host, port = value.rsplit(":", 1)
        broadcaster.add_client(host, int(port))
    microphone_sinks = FanoutSink([
        record_sink,
        VadFrameSink(vad, speaker.playing_event),
        broadcaster,
        voice_link,
    ])
    if args.microphone_device in ("analog", "mcp3204"):
        microphone_factory = lambda: Mcp3204MicrophoneBackend(
            channel=args.microphone_adc_channel, gain=args.microphone_gain)
    else:
        microphone_factory = lambda: AutoArecordBackend(args.microphone_device)
    microphone = MicrophoneCaptureService(
        microphone_factory, microphone_sinks)
    media = MediaService(
        CameraProcessController(), microphone, record_sink, AsyncWavWriter,
        broadcaster=broadcaster, speaker=speaker,
        muxer=AsyncMediaMuxer(mux_audio_video),
    )
    supervisor = SystemSupervisor(LegacyStep7Process(), gnss, media)
    supervisor.voice_link = voice_link
    return supervisor, gnss_writer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--microphone-device", default="analog",
                        help="analog (MCP3204 CH0), auto, or an ALSA device")
    parser.add_argument("--microphone-adc-channel", type=int, default=0)
    parser.add_argument("--microphone-gain", type=float, default=18.0)
    parser.add_argument("--speaker-device", default="default")
    parser.add_argument("--sounds", default="sounds")
    parser.add_argument("--audio-client", action="append", default=[], metavar="HOST:PORT")
    parser.add_argument("--voice-port", type=int, default=50100)
    parser.add_argument("--sound-key", action="append", default=[], metavar="KEY=FILE.wav")
    args = parser.parse_args()
    sound_map = parse_sound_map(args.sound_key)
    stop_event = threading.Event()
    signal.signal(signal.SIGINT, lambda *_: stop_event.set())
    signal.signal(signal.SIGTERM, lambda *_: stop_event.set())
    supervisor, gnss_writer = build_system(args)
    battery = BatteryMonitor()
    console = OperatorConsole()
    recording = False
    last_status = None
    next_display = 0.0
    try:
        battery.start()
        status = supervisor.start(timeout_s=8.0)
        supervisor.voice_link.start()
        print(f"System {status.state.value}: {status.detail}")
        print("w/a/s/d: drive | space: emergency stop | e: LED | r: record | x: stop sound | q: quit")
        if sound_map:
            print("Sounds: " + " | ".join(f"{key}: {name}" for key, name in sound_map.items()))
        console.start()
        while not stop_event.is_set():
            key = console.poll()
            if key is not None:
                recording, keep_running = route_operator_key(supervisor, key, recording, sound_map)
                if not keep_running:
                    stop_event.set()
            statuses = supervisor.tick()
            statuses["battery"] = battery.tick()
            now = time.monotonic()
            signature = tuple((name, value.state.value, value.detail)
                              for name, value in sorted(statuses.items()))
            if signature != last_status and now >= next_display:
                print(" | ".join(f"{name}={value.state.value}:{value.detail}"
                                 for name, value in sorted(statuses.items())), flush=True)
                last_status = signature
                next_display = now + 0.5
            stop_event.wait(0.005)
    finally:
        console.close()
        supervisor.close()
        supervisor.voice_link.close()
        battery.close()
        gnss_writer.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
