#!/usr/bin/env python3
"""PC entry point for TRACER Ground Station."""

from ground_station_hub import main


if __name__ == "__main__":
    main()
