"""Build the static GitHub Pages download without local logs or credentials."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "docs" / "tracer-pc-setup.zip"
ROOT_FILES = (
    "hub.py", "ground_station_hub.py", "ground_station.py", "browser_voice.py",
    "ground_station_voice_client.py", "rover.py", "drive.py", "rover_system.py",
    "rover_drive_sensors.py", "requirements-pc.txt", "connect_ground_station.ps1",
    "start_public_ground_station.ps1", "GROUND_STATION_GUIDE_JA.md",
    "GROUND_STATION_HUB_GUIDE_JA.md", "build_public_package.py",
)


def build():
    files = [ROOT / name for name in ROOT_FILES]
    files += sorted((ROOT / "tracer_runtime").glob("*.py"))
    for folder in ("ground_station_web", "ground_station_hub_web"):
        files += sorted((ROOT / folder).glob("*.html"))
        files += sorted((ROOT / folder).glob("*.css"))
        files += sorted((ROOT / folder).glob("*.js"))
    missing = [path for path in files if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)
    OUTPUT.parent.mkdir(exist_ok=True)
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT).as_posix())
    return OUTPUT


if __name__ == "__main__":
    print(build())
