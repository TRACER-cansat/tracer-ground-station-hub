param(
    [int]$StationPort = 8866,
    [int]$HubPort = 8870
)

$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$runtime = Join-Path $project 'public_runtime'
New-Item -ItemType Directory -Force -Path $runtime | Out-Null
$python = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (-not (Test-Path -LiteralPath $python)) { $python = (Get-Command py -ErrorAction Stop).Source }
$cloudflared = Join-Path $project 'tools\cloudflared.exe'
if (-not (Test-Path -LiteralPath $cloudflared)) {
    New-Item -ItemType Directory -Force -Path (Split-Path $cloudflared) | Out-Null
    Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/download/2026.10.5/cloudflared-windows-amd64.exe' -OutFile $cloudflared
}
$checksum = (Get-FileHash -LiteralPath $cloudflared -Algorithm SHA256).Hash.ToLowerInvariant()
if ($checksum -ne 'db4e4c413612a0916f3e1679d3caaf376f94911952d163028fb726fb2e0516a9') {
    throw 'cloudflared の署名済みリリースとチェックサムが一致しません。'
}

try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:$StationPort/voice_browser.js" -TimeoutSec 3
    $stationReady = $response.StatusCode -eq 200
} catch { $stationReady = $false }
if (-not $stationReady) {
    $hub = Start-Process -FilePath $python -ArgumentList @('hub.py','--host','127.0.0.1','--port',"$HubPort",'--station-port',"$StationPort") `
        -WorkingDirectory $project -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $runtime 'hub.out.log') `
        -RedirectStandardError (Join-Path $runtime 'hub.err.log')
    Set-Content -LiteralPath (Join-Path $runtime 'hub.pid') -Value $hub.Id
    Start-Sleep -Seconds 2
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:$StationPort/voice_browser.js" -TimeoutSec 5
    if ($response.StatusCode -ne 200) { throw '地上局の起動を確認できません。' }
}

$urlFile = Join-Path $runtime 'current_url.txt'
$pidFile = Join-Path $runtime 'tunnel.pid'
if ((Test-Path $pidFile) -and (Test-Path $urlFile)) {
    $oldPid = [int](Get-Content -LiteralPath $pidFile -Raw)
    $oldUrl = (Get-Content -LiteralPath $urlFile -Raw).Trim()
    if ((Get-Process -Id $oldPid -ErrorAction SilentlyContinue) -and $oldUrl) {
        try {
            if ((Invoke-WebRequest -Uri "$oldUrl/voice_browser.js" -TimeoutSec 5).StatusCode -eq 200) {
                Write-Output "公開操作画面: $oldUrl"
                return
            }
        } catch { }
    }
}

$log = Join-Path $runtime 'tunnel.err.log'
$tunnel = Start-Process -FilePath $cloudflared -ArgumentList @('tunnel','--url',"http://127.0.0.1:$StationPort",'--no-autoupdate') `
    -WorkingDirectory $project -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput (Join-Path $runtime 'tunnel.out.log') -RedirectStandardError $log
Set-Content -LiteralPath $pidFile -Value $tunnel.Id
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Seconds 1
    $match = [regex]::Match((Get-Content -LiteralPath $log -Raw -ErrorAction SilentlyContinue), 'https://[a-z0-9-]+\.trycloudflare\.com')
    if ($match.Success) {
        Set-Content -LiteralPath $urlFile -Value $match.Value
        Write-Output "公開操作画面: $($match.Value)"
        Write-Output 'PCを再起動すると公開URLは変わります。新しいURLを共有してください。'
        return
    }
    if ($tunnel.HasExited) { break }
}
throw 'HTTPS公開URLを取得できませんでした。public_runtime/tunnel.err.log を確認してください。'
