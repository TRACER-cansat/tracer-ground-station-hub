#!/usr/bin/env python3
"""Raspberry Pi entry point for TRACER Ground Station."""

from ground_station import main


if __name__ == "__main__":
    main()
